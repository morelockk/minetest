--CRAFTS
--CODE OF BAUBLES AND LIGHT NODES

print("Loading 'christmas_craft/lights.lua'")
-- undecorated coloured glass, all using plain glass texture
--code from abriglass mod
local colors_list = {
{"blue", "Blue", "0000FF99"},
{"green", "Green", "00FF0099"},
{"red", "Red", "FF000099"},
{"cyan", "Cyan", "00FFFF99"},
{"magenta", "Magenta", "FF00FF99"},
{"orange", "Orange", "EF7F1A99"},
{"yellow", "Yellow", "FFFF0099"},
{"white", "Frosted", "FFFFFF99"},
{"black", "Black", "00000099"},
}

for i in ipairs(colors_list) do
name = colors_list[i][1]
description = colors_list[i][2]
color = colors_list[i][3]

--minetest.register_node("christmas:bauble_"..name.."_baubles",{
minetest.register_node("christmas_craft:bauble_"..name,{
description = description.." Bauble",
drawtype = "nodebox",
tiles = 
{
"christmas_baubles.png^[colorize:#"..color.."^christmas_baubles_top.png",
"christmas_baubles.png^[colorize:#"..color.."^christmas_baubles_side.png",
"christmas_baubles.png^[colorize:#"..color.."^christmas_baubles_side.png",
    },
  	is_ground_content = true,
  	paramtype = "light",
  	groups = {crumbly=3, xmas=1},
  	sounds = default.node_sound_glass_defaults(),
  	node_box = {
  type = "fixed",
      fixed = {
  			{-0.0625, 0.375, -0.0625, 0.0625, 0.5, 0.0625}, -- NodeBox1
  			{-0.25, -0.0625, -0.25, 0.25, 0.4375, 0.25}, -- NodeBox2
  		}
  	},
  	selection_box = {
  		type = "fixed",
      fixed = {
  			{-0.0625, 0, -0.0625, 0.0625, 0.5, 0.0625}, -- NodeBox1
  			{-0.25, -0.0625, -0.25, 0.25, 0.4375, 0.25}, -- NodeBox2
  		},
  	},
  })

minetest.register_craft({
output='christmas_craft:bauble_'..name..' 6',
recipe = {
{"default:glass","default:gold_ingot", "default:glass"},
{"default:glass","dye:"..name, "default:glass"},
{"default:glass","default:glass", "default:glass"},
}
})
end

minetest.register_node("christmas_craft:glass_bauble",{
  description = "Bauble",
  drawtype = "nodebox",
  tiles = {
    "christmas_baubles-top.png^christmas_baubles_top.png",
    "christmas_baubles-top.png^christmas_baubles_side.png",
   "christmas_baubles-side.png^christmas_baubles_side.png",
  },
  is_ground_content = true,
  paramtype = "light",
  use_texture_alpha = true,
  groups = {crumbly=3,xmas=1},
	sounds = default.node_sound_glass_defaults(),
  node_box = {
    type = "fixed",
    fixed = {
      {-0.0625, 0.375, -0.0625, 0.0625, 0.5, 0.0625}, -- NodeBox1
      {-0.25, -0.0625, -0.25, 0.25, 0.4375, 0.25}, -- NodeBox2
    }
  },
  selection_box = {
    type = "fixed",
    fixed = {
      {-0.0625, 0, -0.0625, 0.0625, 0.5, 0.0625}, -- NodeBox1
      {-0.25, -0.0625, -0.25, 0.25, 0.4375, 0.25}, -- NodeBox2
    },
  },
})

minetest.register_node("christmas_craft:christmas_star", {
	description = "Christmas star",
	drawtype = "plantlike",
	light_source = 10,
	tiles = {"christmas_star.png"},
	is_ground_content = true,
	groups = {crumbly=3, xmas=1},
	sounds = default.node_sound_glass_defaults(),
})

minetest.register_node("christmas_craft:christmas_wall_lights", {
	description = "christmas Wall lights",
	drawtype = "signlike",
	light_source = 10,
	walkable = false,
	tiles = {
		{name="christmas_lights_animated.png", animation={type="vertical_frames", aspect_w=32, aspect_h=32, length=3.0}},
		},
	inventory_image =  "christmas_lights.png",
	wield_image = "christmas_lights.png",
	paramtype = "light",
	paramtype2 = "wallmounted",
	selection_box = {
		type = "wallmounted",
	},
	groups = {oddly_breakable_by_hand = 3,xmas=1,not_in_craft_guide=1},
})

minetest.register_node("christmas_craft:christmas_lights", {
	description = "Christmas Lights",
	tiles = {
		{name="christmas_lights_animated.png", animation={type="vertical_frames", aspect_w=32, aspect_h=32, length=3.0}},
		},
	inventory_image =  "christmas_lights.png",
	wield_image = "christmas_lights.png",
	drawtype = "nodebox",
	walkable = false,
	light_source = 10,
	paramtype = "light",
  paramtype2 = "facedir",
  groups = {crumbly=3,xmas=1},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5, 0.25, 0, 0.5, 0.5, 0}, -- NodeBox7
		}
	},
	selection_box = {
    type = "fixed",
    fixed = {
    {-0.5, 0.25, -0.125, 0.5, 0.5, 0.125}, -- NodeBox13
    },
  },
})

minetest.register_craft({
	output = "christmas_craft:christmas_lights 4",
	recipe = {
		{"farming:string","default:mese_crystal", "farming:string"},
		{"default:glass","default:glass", "default:glass"},
	}
})

minetest.register_craft({
	output = "christmas_craft:christmas_wall_lights 4",
	recipe = {
		{"","default:mese_crystal", ""},
		{"default:glass","default:glass", "default:glass"},
	}
})

minetest.register_craft({
	output = "christmas_craft:christmas_star ",
	recipe = {
		{"","default:gold_ingot",""},
		{"default:gold_ingot","default:gold_ingot","default:gold_ingot"},
		{"default:gold_ingot","","default:gold_ingot"},
	}
})
