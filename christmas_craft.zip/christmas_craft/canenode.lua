print("Loading 'christmas_craft/canenode.lua'")

minetest.register_craft({output = "christmas_craft:candy_cane",recipe = {{"","christmas_craft:sugar","christmas_craft:sugar"},{"","christmas_craft:sugar",""},{"christmas_craft:sugar","",""},}})

minetest.register_craft({output = "christmas_craft:candy_cane_node",recipe = {{"christmas_craft:candy_cane","christmas_craft:candy_cane","christmas_craft:candy_cane"},{"christmas_craft:candy_cane","","christmas_craft:candy_cane"},{"christmas_craft:candy_cane","christmas_craft:candy_cane","christmas_craft:candy_cane"},}})

minetest.register_craft({output = "christmas_craft:candy_cane_tree",recipe = {{"christmas_craft:candy_cane","christmas_craft:candy_cane","christmas_craft:candy_cane"},{"christmas_craft:candy_cane","group:tree","christmas_craft:candy_cane"},{"christmas_craft:candy_cane","christmas_craft:candy_cane","christmas_craft:candy_cane"},}})

minetest.register_node("christmas_craft:candy_cane", {
description = "Candy Cane",
drawtype = "torchlike",
tiles = {"christmas_candy_cain_stick_wall.png"},
inventory_image = "christmas_candy_cain_stick.png",
wield_image = "christmas_candy_cain_stick.png",
paramtype = "light",
paramtype2 = "wallmounted",
sunlight_propagates = true,
walkable = false,
on_use = minetest.item_eat(1),
selection_box = {type = "wallmounted",wall_side = {-0.5, -0.3, -0.1, -0.5+0.3, 0.3, 0.1},},
groups = {choppy=2,dig_immediate=3,flammable=1,xmas=1},
legacy_wallmounted = true,
sounds = default.node_sound_defaults(),
})

minetest.register_node("christmas_craft:candy_cane_node", {
description = "Giant Candy Cane",
tiles = {"christmas-candy_cabe.png",},
is_ground_content = true,
paramtype2 = "facedir",
groups = {choppy = 2, oddly_breakable_by_hand = 1, flammable = 2,xmas=1},
sounds = default.node_sound_wood_defaults(),
})

minetest.register_node("christmas_craft:candy_cane_tree", {
description = "Candy Cane Tree",
tiles = {"christmas-candy_cabe_top.png", "christmas-candy_cabe_top.png","christmas-candy_cabe.png"},
paramtype2 = "facedir",
is_ground_content = false,
groups = {choppy = 2, oddly_breakable_by_hand = 1, flammable = 2,xmas=1},
sounds = default.node_sound_wood_defaults(),
on_place = minetest.rotate_node
})
