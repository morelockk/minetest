print("Loading 'christmas_craft/presents.lua'")
local colors_list = {
{"blue", "Blue", "0000FF99"},
{"green", "Green", "00FF0099"},
{"red", "Red", "FF000099"},
{"cyan", "Cyan", "00FFFF99"},
{"magenta", "Magenta", "FF00FF99"},
{"orange", "Orange", "EF7F1A99"},
{"yellow", "Yellow", "FFFF0099"},
{"white", "Frosted", "FFFFFF99"},
{"black", "Black", "00000099"},
}

for i in ipairs(colors_list) do
name = colors_list[i][1]
description = colors_list[i][2]
color = colors_list[i][3]

minetest.register_node("christmas_craft:Present_"..name, {
  description = description.." Christmas Present",
  tiles = {
    "christmas_present.png^[colorize:#"..color.."^christmas_bow_top.png",
    "christmas_present.png^[colorize:#"..color.."^christmas_bow_bottom.png",
    "christmas_present.png^[colorize:#"..color.."^christmas_bow_side.png"},
  is_ground_content = true,
  groups = {crumbly=3,xmas=1},
  drop = {
    max_items = 1, min_items = 1, items = {
      {items = {'default:bookshelf'},	rarity = 90,},
      {items = {'default:pick_mese'},	rarity = 80,},
      {items = {'default:shovel_steel'},	rarity = 90,},
      {items = {'default:axe_steel'},	rarity = 90,},
      {items = {'default:pick_steel'},	rarity = 90,},
      {items = {'default:sign_wall'},	rarity = 80,},
      {items = {'default:chest'},	rarity = 80,},
      {items = {'default:furnace'},	rarity = 80,},
      {items = {'default:steelblock'},	rarity = 80,},
      {items = {'default:coal_lump'},	rarity = 80,},
      {items = {'default:pick_diamond'},	rarity = 75,},
      {items = {'default:shovel_diamond'},	rarity = 75,},
      {items = {'default:axe_diamond'},	rarity = 75,},
      {items = {'default:diamondblock'},	rarity = 75},
      {items = {'fake_fire:flint_and_steel'},	rarity = 90,},
      {items = {'default:chest_locked'},	rarity = 80,},
      {items = {'default:brick'},	rarity = 80,},
      {items = {'default:dirt_with_grass'}, rarity = 80,},
    }},
  sounds = default.node_sound_dirt_defaults({
    footstep = {name="default_grass_footstep", gain=0.4},
  }),
})

minetest.register_craft({
	output = "christmas_craft:Present_"..name ,
	recipe = {
		{"christmas_craft:paper_"..name,"christmas_craft:red_ribbon", "christmas_craft:paper_"..name},
		{"christmas_craft:paper_"..name,"christmas_craft:present_box", "christmas_craft:paper_"..name},
		{"christmas_craft:paper_"..name,"christmas_craft:red_ribbon", "christmas_craft:paper_"..name},
	}
})

minetest.register_node("christmas_craft:paper_"..name, {
description = description.." paper",
inventory_image = "default_paper.png^[colorize:#"..color,
stack_max = 99,
groups = {crumbly=3,xmas=1},
liquids_pointable = false,
})

minetest.register_craft({
type = "shapeless",
output = 'christmas_craft:paper_'.. name,
recipe = {'dye:'..name,'default:paper'},
})

end

minetest.register_node("christmas_craft:present_box", {
  description = "Present Box",
  tiles = {"christmas_present_box.png"},
  is_ground_content = true,
  paramtype = "light",
  groups = {crumbly=3,xmas=1},
  sounds = default.node_sound_sand_defaults(),
})

minetest.register_craft({
	output = "christmas_craft:present_box",
	recipe = {
		{"default:paper","default:paper", "default:paper"},
		{"default:paper","christmas_craft:wish_list", "default:paper"},
		{"default:paper","default:paper", "default:paper"},
	}
})

minetest.register_craftitem("christmas_craft:red_ribbon", {
description = "Red Ribbon",
inventory_image = "christmas_craft_red_ribbon.png",
stack_max = 99,
liquids_pointable = false,
})

minetest.register_craft({
	type = "shapeless",
	output = 'christmas_craft:red_ribbon',
	recipe = {'dye:red','farming:string'},
})
