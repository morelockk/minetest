print("Loading 'christmas_craft/init.lua'")
local modpath = minetest.get_modpath("christmas_craft")
local snow = false
local enable_crafts = true
if snow == true then minetest.log("info","let it snow, let it snow, let it snow.") dofile(modpath.."/snow.lua") end ----if snow enabled, let it snow
--if crafts enabled, register the craft recieps
if enable_crafts == true then minetest.log("info","registering craft rezieps for snow mod")
dofile(modpath.."/lights.lua")--baubles and lighting
dofile(modpath.."/canenode.lua")--canenode
dofile(modpath.."/others.lua")--nodes
dofile(modpath.."/food.lua")--all stuff related to food
dofile(modpath.."/presents.lua")--all related to the presents
end

if minetest.get_modpath("mtfoods") then dofile(modpath.."/mtfoods.lua") end --mtfoods mod support
--end

--minetest.register_alias("christmas_craft:snow_block", "default:snowblock")
--minetest.register_alias("christmas_craft:silver_baubles", "christmas_craft:white_baubles")
--minetest.register_alias("christmas_craft:Christmas_present", "christmas_craft:Christmas_present_white")

