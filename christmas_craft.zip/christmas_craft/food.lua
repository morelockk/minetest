print("Loading 'christmas_craft/food.lua'")

minetest.register_craftitem("christmas_craft:christmas_pudding_mix", {description = "Christmas Pudding Mix",inventory_image = "christmas_pud-mix.png",})
minetest.register_craft({output = "christmas_craft:christmas_pudding_mix",recipe = {{"christmas_craft:sugar","christmas_craft:sugar","christmas_craft:sugar"},{"default:apple","farming:flour","default:apple"},{"farming:flour","default:apple","farming:flour"},}})
minetest.register_craft({type = "cooking",output = "christmas_craft:christmas_pudding",recipe = "christmas_craft:christmas_pudding_mix",})

minetest.register_node("christmas_craft:christmas_pudding", {
	description = "Christmas Pudding",
	tiles = {
		"christmas_pud-top.png",
		"christmas_pud-bot.png",
		"christmas_pud-side.png",
	},
	drawtype = "nodebox",
	paramtype = "light",
	groups = {crumbly=3,xmas=1},
	sounds = default.node_sound_sand_defaults(),
		on_use = minetest.item_eat(8),
	node_box = {
		type = "fixed",
		fixed = {
			{-0.3125, -0.5, -0.3125, 0.3125, 0.0625, 0.3125}, -- NodeBox2
			{-0.0625, 0.0625, 0, 0, 0.125, 0.0625}, -- NodeBox4
			{0, 0.0625, -0.0625, 0.0625, 0.125, 0}, -- NodeBox5
		}
	}
})

minetest.register_craftitem("christmas_craft:ginger_mix", {
	description = "Christmas Ginger Mix",
	inventory_image = "christmas_ginger-mix.png",
})

minetest.register_craft({
	output = "christmas_craft:ginger_mix",
	recipe = {
		{"christmas_craft:sugar","christmas_craft:sugar"},
		{"farming:flour","farming:flour"},
	}
})

minetest.register_craft({
	type = "cooking",
	output = "christmas_craft:ginger_bread_man",
	recipe = "christmas_craft:ginger_mix",
})

minetest.register_craftitem("christmas_craft:sugar", {
	description = "Christmas sugar",
	inventory_image = "christmas_sugar.png",
})

minetest.register_craft({
  type = "cooking",
  output = "christmas_craft:sugar",
  recipe = "group:flower",
})

minetest.register_node("christmas_craft:ginger_bread_man", {
	description = "Ginger Bread Man",
	drawtype = "signlike",
	walkable = false,
	tiles =
	{name="ginger_bread_man.png", animation={type="vertical_frames", aspect_w=32, aspect_h=32, length=3.0}},
	inventory_image =  "ginger_bread_man.png",
	wield_image = "ginger_bread_man.png",
	paramtype = "light",
	paramtype2 = "wallmounted",
	selection_box = {
	type = "wallmounted",
	},
  groups = {oddly_breakable_by_hand = 3,xmas=1},
  on_use = minetest.item_eat(4),
})
