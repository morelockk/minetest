print("Loading 'christmas_craft/others.lua'")
--CHRISTMAS LEAVES
minetest.register_craft({
	output = "christmas_craft:christmas_leaves 4",
	recipe = {
		{"default:leaves","default:leaves"},
		{"default:leaves","default:leaves"},
	}
})

minetest.register_node("christmas_craft:christmas_leaves", {
	description = "Christmas leaves",
	drawtype = "allfaces_optional",
	tiles = {"christmas_leaves.png"},
	is_ground_content = false,
	paramtype = "light",
	groups = {crumbly=3,xmas=1},
	sounds = default.node_sound_sand_defaults(),
})

--CHRISTMAS WREATH
minetest.register_node("christmas_craft:christmas_wreath", {
	description = "Christmas Wreath",
	drawtype = "signlike",
	walkable = false,
	tiles = {
		{name="christmas_wreath.png", animation={type="vertical_frames", aspect_w=32, aspect_h=32, length=3.0}},
		},
	inventory_image =  "christmas_wreath.png",
	paramtype = "light",
	paramtype2 = "wallmounted",
	selection_box = {
		type = "wallmounted",
	},
	groups = {oddly_breakable_by_hand = 3,xmas=1},
})

minetest.register_craft({
	output = "christmas_craft:christmas_wreath ",
	recipe = {
		{"christmas_craft:christmas_leaves","christmas_craft:christmas_leaves","christmas_craft:christmas_leaves"},
		{"christmas_craft:christmas_leaves","","christmas_craft:christmas_leaves"},
		{"christmas_craft:christmas_leaves","christmas_craft:red_ribbon","christmas_craft:christmas_leaves"},
	}
})

--SNOW SLABS AND STEPS
minetest.register_node("christmas_craft:snow_steps_2",{
  description = "Snow Stairs",
  drawtype = "nodebox",
  tiles = {"default_snow.png"},
  is_ground_content = true,
	walkable = false,
  paramtype = "light",
  paramtype2 = "facedir",
  groups = {crumbly=3,xmas=1},
	sounds = default.node_sound_dirt_defaults({
			footstep = {name = "default_snow_footstep", gain = 0.15},
			dug = {name = "default_snow_footstep", gain = 0.2},
			dig = {name = "default_snow_footstep", gain = 0.2}
		}),
	drop = 'default:snow 2',
  node_box = {
    type = "fixed",
    fixed = {
      {-0.5, -1, -0.5, 0.5, -0.625, 0}, -- NodeBox2
  			{-0.5, -0.5, 0, 0, -0.125, 0.5}, -- NodeBox3
  			{0, -1, 0, 0.5, -0.625, 0.5}, -- NodeBox5
    }
  },
})

minetest.register_node("christmas_craft:snow_steps_1",{
  description = "Snow Stairs",
  drawtype = "nodebox",
  tiles = {"default_snow.png"},
  is_ground_content = true,
	walkable = false,
  paramtype = "light",
  paramtype2 = "facedir",
  groups = {crumbly=3,xmas=1},
	sounds = default.node_sound_dirt_defaults({
		footstep = {name = "default_snow_footstep", gain = 0.15},
		dug = {name = "default_snow_footstep", gain = 0.2},
		dig = {name = "default_snow_footstep", gain = 0.2}
	}),
	drop = 'default:snow 2',
  node_box = {
    type = "fixed",
    fixed = {
      {0, -1, -0.5, 0.5, -0.625, 0}, -- NodeBox2
  			{-0.5, -0.5, 0, 0.5, -0.125, 0.5}, -- NodeBox3
  			{-0.5, -0.5, -0.5, 0, -0.125, 0.0625}, -- NodeBox4
    }
  },
})

minetest.register_node("christmas_craft:snow_steps",{
  description = "Snow Stairs",
  drawtype = "nodebox",
  tiles = {"default_snow.png"},
  is_ground_content = true,
	walkable = false,
  paramtype = "light",
  paramtype2 = "facedir",
  groups = {crumbly=3,xmas=1},
	sounds = default.node_sound_dirt_defaults({
		footstep = {name = "default_snow_footstep", gain = 0.15},
		dug = {name = "default_snow_footstep", gain = 0.2},
		dig = {name = "default_snow_footstep", gain = 0.2}
	}),
	drop = 'default:snow 2',
  node_box = {
    type = "fixed",
    fixed = {
      {-0.5, -1, -0.5, 0.5, -0.625, 0}, -- NodeBox2
  			{-0.5, -0.5, 0, 0.5, -0.125, 0.5}, -- NodeBox3
    }
  },
})

minetest.register_node("christmas_craft:snow_slab",{
  description = "Snow Slab",
  drawtype = "nodebox",
  tiles = {"default_snow.png"},
  is_ground_content = true,
	walkable = false,
  paramtype = "light",
  paramtype2 = "facedir",
  groups = {crumbly=3,xmas=1},
	sounds = default.node_sound_dirt_defaults({
			footstep = {name = "default_snow_footstep", gain = 0.15},
			dug = {name = "default_snow_footstep", gain = 0.2},
			dig = {name = "default_snow_footstep", gain = 0.2}
		}),
	drop = 'default:snow',
  node_box = {
    type = "fixed",
    fixed = {
    {-0.5, -1, -0.5, 0.5, -0.625, 0.5}, -- NodeBox2
    }
  },
  selection_box = {
    type = "fixed",
    fixed = {
    {-0.5, -1, -0.5, 0.5, -0.4375, 0.5}, -- NodeBox2
    },
  },
})

minetest.register_craft({
	output = "christmas_craft:snow_slab 3",
	recipe = {
		{"default:snow","default:snow","default:snow"},
  }
})

minetest.register_craft({
	output = "christmas_craft:snow_steps 3",
	recipe = {
    {"default:snow","",""},
    {"default:snow","default:snow",""},
		{"default:snow","default:snow","default:snow"},
  }
})

minetest.register_craft({
	output = "christmas_craft:snow_steps_1 3",
	recipe = {
    {"christmas_craft:snow_steps","christmas_craft:snow_steps",""},
    {"christmas_craft:snow_steps","",""},
  }
})

minetest.register_craft({
	output = "christmas_craft:snow_steps_2",
	recipe = {
    {"christmas_craft:snow_steps"},
  }
})

--SNOWMAN
minetest.register_craft({
	output = "christmas_craft:snowman",
	recipe = {
		{"default:coal_lump","default:snow","default:coal_lump"},
		{"default:snow","christmas_craft:snowball","default:snow"},
		{"default:coal_lump","default:coal_lump","default:coal_lump"},
	}
})

minetest.register_node("christmas_craft:snowman", {
	description = "Snowman",
	tiles = {"default_snow.png", "default_snow.png", "default_snow.png",
		"default_snow.png", "default_snow.png", "Snowman_F.png"},
	is_ground_content = true,
	paramtype2 = "facedir",
	groups = {crumbly=3,xmas=1},
	sounds = default.node_sound_sand_defaults(),
})

--STOCKING
local stocking_formspec = [[
size[8,9]
list[context;main;0,0.3;8,4;]
list[current_player;main;0,4.85;8,1;]
list[current_player;main;0,6.08;8,3;8]
listring[context;main]
listring[current_player;main]
]]

minetest.register_node("christmas_craft:stocking", {
	description = "Christmas Stocking",
	drawtype = "signlike",
	walkable = false,
	tiles =
	{name="christmas_stocking.png", animation={type="vertical_frames", aspect_w=32, aspect_h=32, length=3.0}},
	inventory_image =  "christmas_stocking.png",
	wield_image = "christmas_stocking.png",
	paramtype = "light",
	paramtype2 = "wallmounted",
	selection_box = {
	type = "wallmounted",
	},
	groups = {oddly_breakable_by_hand = 3,xmas=1},
	on_construct = function(pos)
		local meta = minetest.get_meta(pos)
		meta:set_string("formspec", stocking_formspec )
		meta:set_string("infotext", "Christmas Stocking")
		local inv = meta:get_inventory()
		inv:set_size("main", 16)
	end,
	can_dig = function(pos,player)
		local meta = minetest.get_meta(pos);
		local inv = meta:get_inventory()
		return inv:is_empty("main")
	end,
	on_metadata_inventory_move = function(pos, from_list, from_index, to_list, to_index, count, player)
		minetest.log("action", player:get_player_name()..
				" moves stuff in box at "..minetest.pos_to_string(pos))
	end,
	on_metadata_inventory_put = function(pos, listname, index, stack, player)
		minetest.log("action", player:get_player_name()..
				" moves stuff to box at "..minetest.pos_to_string(pos))
	end,
	on_metadata_inventory_take = function(pos, listname, index, stack, player)
		minetest.log("action", player:get_player_name()..
				" takes stuff from box at "..minetest.pos_to_string(pos))
	end,
})

--WISHLIST
minetest.register_node("christmas_craft:wish_list", {
description = "Wish list",
inventory_image = "christmas_craft_which_list.png",
stack_max = 99,
groups = {crumbly=3,xmas=1},
liquids_pointable = false,
})

minetest.register_craft({
	type = "shapeless",
	output = 'christmas_craft:wish_list',
	recipe = {'default:stick','default:mese_crystal','default:paper','dye:black'},
})
