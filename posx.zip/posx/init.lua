--LAST-LOGIN,PRIVS,MODS,WHO,TIME COLORIZADOS
--		if not core.check_player_privs(name, {bring=true}) then
--			return false, "You don't have permission to teleport other players (missing bring privilege)"

--VARIABLES QUE LE DAN COLOR A LOS MENSAJES
local colorize
if minetest.colorize then
	colorize = minetest.colorize
end
local AZUL_OSCURO = "#00AAAA"
local CELESTE = "#00FFFF"
local MORADO_OSCURO = "#AA00AA"
local MORADO = "#FF00FF"
local VERDE_OSCURO = "#00AA00"
--VARIABLES Y LOS NOMBRES QUE TELETRANSPORTAN
--lp ES LA LISTA DE TODOS LOS LUGARES
local spawn = { x = 0, y = 10, z = 0 }
local granjas = { x = 409, y = 5, z = -2701 }
local mina = { x = 308, y = -576, z = -2557 }
local casa = { x = 353, y = 26, z = -2768 }
local ice = { x = 16, y = 3, z = 4937 }
local marble = { x = 408, y = -352, z = -2465 }
local corals = { x = 423, y = 2, z = -2504 } 
local corals2 = { x = 1093, y = 3, z = -2878 }
local rtuff = { x = 2996, y = 2, z = -2707 }
local serpentine = { x = 387, y = -508, z = -2502 }
local gneiss = { x = 347, y = -505, z = -2471 } 
local dcobble = { x = 3028, y = 16, z = -2762 }
minetest.register_on_chat_message(function(name, message)
if message == "lp" then
minetest.chat_send_player(name,colorize(AZUL_OSCURO,"###Lista_posiciones:#spawn#casa#mina#granjas#\n###Recursos:#marble#corals#corals2#ice#rtuff#dcobble#serpentine#gneiss"))
end
end)
minetest.register_on_chat_message(function(name, message)
if message == "spawn" then
position = minetest.get_player_by_name(name)
position:setpos(spawn)
minetest.chat_send_player(name,colorize(CELESTE,"###Spawn..."))
--minetest.sound_play("teleport", {
--	max_hear_distance = 50,
--})
--available sounds
--electricity
--paperclip1 y 2
--click
--teleport
end
end)
minetest.register_on_chat_message(function(name, message)
	if message == "granjas" then
		position = minetest.get_player_by_name(name)
		position:setpos(granjas)
minetest.chat_send_player(name,colorize(CELESTE,"###Granjas del\vAdmin...."))
	end
end)
minetest.register_on_chat_message(function(name, message)
	if message == "mina" then
		position = minetest.get_player_by_name(name)
		position:setpos(mina)
minetest.chat_send_player(name,colorize(CELESTE,"###mina del\vAdmin...."))
	end
end)
minetest.register_on_chat_message(function(name, message)
	if message == "marble" then
		position = minetest.get_player_by_name(name)
		position:setpos(marble)
minetest.chat_send_player(name,colorize(CELESTE,"###mina de Marble del \vadmin...."))
	end
end)
minetest.register_on_chat_message(function(name, message)
	if message == "corals" then
		position = minetest.get_player_by_name(name)
		position:setpos(corals)
minetest.chat_send_player(name,colorize(CELESTE,"###Corales del \vadmin...."))
	end
end)
minetest.register_on_chat_message(function(name, message)
	if message == "rtuff" then
		position = minetest.get_player_by_name(name)
		position:setpos(rtuff)
minetest.chat_send_player(name,colorize(CELESTE,"###Veta de Rhyolitic Tuff del \vadmin...."))
	end
end)
minetest.register_on_chat_message(function(name, message)
	if message == "dcobble" then
		position = minetest.get_player_by_name(name)
		position:setpos(dcobble)
minetest.chat_send_player(name,colorize(CELESTE,"###Veta de Desert Cobblestone del \vadmin...."))
	end
end)
minetest.register_on_chat_message(function(name, message)
	if message == "casa" then
		position = minetest.get_player_by_name(name)
		position:setpos(casa)
minetest.chat_send_player(name,colorize(CELESTE,"###Casa del \vadmin...."))
	end
end)
minetest.register_on_chat_message(function(name, message)
	if message == "corals2" then
		position = minetest.get_player_by_name(name)
		position:setpos(corals2)
minetest.chat_send_player(name,colorize(CELESTE,"###Corales \v...."))
	end
end)
minetest.register_on_chat_message(function(name, message)
	if message == "ice" then
		position = minetest.get_player_by_name(name)
		position:setpos(ice)
minetest.chat_send_player(name,colorize(CELESTE,"###Veta de \v ice...."))
	end
end)
minetest.register_on_chat_message(function(name, message)
	if message == "serpentine" then
		position = minetest.get_player_by_name(name)
		position:setpos(serpentine)
minetest.chat_send_player(name,colorize(CELESTE,"###Veta de \v serpentine...."))
	end
end)
minetest.register_on_chat_message(function(name, message)
	if message == "gneiss" then
		position = minetest.get_player_by_name(name)
		position:setpos(gneiss)
minetest.chat_send_player(name,colorize(CELESTE,"###Veta de \v gneiss...."))
	end
end)
--minetest.register_on_chat_message(function(name, message)
--	if message == "lol" then
--		position = minetest.get_player_by_name(name)
--		position:setpos(chinche)
--minetest.chat_send_player(name,colorize(CELESTE,"Moviendo al Spawn......"))
--	end
--end)
--COMANDOS DEL SERVIDOR
minetest.register_chatcommand("who", {
    params = "",
    description = "List all connected players.",
    func = function(name)
        connected_players_string = '###Connected: '
 
        for _,player in ipairs(minetest.get_connected_players()) do
            connected_players_string  =  connected_players_string .. 
                                         player:get_player_name() .. 
                                         ' '
        end
        minetest.chat_send_player(name,colorize(MORADO_OSCURO, connected_players_string))
 
        return true
    end
})

core.register_chatcommand("mods", {
	params = "",
	description = "List mods installed on the server",
	privs = {},
	func = function(name, param)
       minetest.chat_send_player(name,colorize(MORADO_OSCURO, table.concat(core.get_modnames(), ", ")))
		return true
	end,
})

core.register_chatcommand("ll", {
	params = "[name]",
	description = "Get the last login time of a player",
	func = function(name, param)
		if param == "" then
			param = name
		end
		local pauth = core.get_auth_handler().get_auth(param)
		if pauth and pauth.last_login then
       minetest.chat_send_player(name,colorize(MORADO_OSCURO, "###Last login time was " ..
				os.date("!%Y-%m-%dT%H:%M:%SZ, UTC TIME", pauth.last_login)))
			-- Time in UTC, ISO 8601 format
			return true
		end
		return false, "Last login time is unknown"
	end,
})

core.register_chatcommand("privs", {
	params = "<name>",
	description = "Print privileges of player",
	func = function(caller, param)
		param = param:trim()
		local name = (param ~= "" and param or caller)
minetest.chat_send_player(name,colorize(MORADO_OSCURO,"###Privileges of " .. name .. ": "
			.. core.privs_to_string(
				core.get_player_privs(name), ' ')))
		return true
	end,
})

core.register_chatcommand("me", {
	params = "<action>",
	description = "Display chat action (e.g., '/me orders a pizza' displays"
			.. " '<player name> orders a pizza')",
	privs = {shout=true},
	func = function(name, param)
		core.chat_send_all(colorize(VERDE_OSCURO,"### " .. name .. " " .. param))
	end,
})

core.register_chatcommand("time", {
	params = "<0..23>:<0..59> | <0..24000>",
	description = "Set time of day",
	privs = {},
	func = function(name, param)
		if param == "" then
			local current_time = math.floor(core.get_timeofday() * 1440)
			local minutes = current_time % 60
			local hour = (current_time - minutes) / 60
minetest.chat_send_player(name,colorize(MORADO_OSCURO,("###Current time is %d:%02d"):format(hour, minutes)))
			return true
		end
		local player_privs = core.get_player_privs(name)
		if not player_privs.settime then
			return false, "You don't have permission to run this command " ..
				"(missing privilege: settime)."
		end
		local hour, minute = param:match("^(%d+):(%d+)$")
		if not hour then
			local new_time = tonumber(param)
			if not new_time then
				return false, "Invalid time."
			end
			-- Backward compatibility.
			core.set_timeofday((new_time % 24000) / 24000)
			core.log("action", name .. " sets time to " .. new_time)
			return true, "Time of day changed."
		end
		hour = tonumber(hour)
		minute = tonumber(minute)
		if hour < 0 or hour > 23 then
			return false, "Invalid hour (must be between 0 and 23 inclusive)."
		elseif minute < 0 or minute > 59 then
			return false, "Invalid minute (must be between 0 and 59 inclusive)."
		end
		core.set_timeofday((hour * 60 + minute) / 1440)
		core.log("action", ("%s sets time to %d:%02d"):format(name, hour, minute))
		return true, "Time of day changed."
	end,
})

core.register_chatcommand("days", {
	description = "Display day count",
	func = function(name, param)
minetest.chat_send_player(name,colorize(MORADO_OSCURO,"###Current day is " .. core.get_day_count()))
		return true
	end
})

--EL ESQUEMA PARA TELETRANSPORTARSE, PERO PRIMERO DEBE HABER UNA VARIABLE -LOCAL- AL PRINCIPIO
--minetest.register_on_chat_message(function(name, message)
--	if message == "lg" then
--		position = minetest.get_player_by_name(name)
--		position:setpos(spawn)
--minetest.chat_send_player(name,colorize(CELESTE,"Moviendo al Spawn......"))
--	end
--end)
