local modpath = minetest.get_modpath("abritorch").. DIR_DELIM

dofile(modpath.."torches.lua")
dofile(modpath.."crafting.lua")