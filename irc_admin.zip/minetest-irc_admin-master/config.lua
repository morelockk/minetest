
mt_irc_admin.users = {
    -- admin = "1234";
    kaeza = "1234";
};
