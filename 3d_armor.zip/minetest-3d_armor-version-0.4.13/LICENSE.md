3D Armor - Visible Player Armor
===============================

License Source Code: Copyright (C) 2013-2018 Stuart Jones - LGPL v2.1

Armor Textures: Copyright (C) 2017-2018 davidthecreator - CC-BY-SA 3.0

Special credit to Jordach and MirceaKitsune for providing the default 3d character model.

