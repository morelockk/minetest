===FARMING_PLUS+ MOD for MINETEST===
version 1.04
by MTDad
--Built from PilzAdam's Farming_Plus, Original WTFPL License Below.
--Cucumber and Corn textures, plus some code, come from Doc's Docfarming mod.
--Melon, Coffee Plant and Corn on the Cob come from Tenplus1's Farming Redo Mod.
--Mini Pumpkin and Jack o Lantern by JP
--To integrate with hud and diet I had to study their code, so any resemblance to the code of Blockmen and Rubenwardy is NOT accidental.
--Anything else not of PilzAdam's original creation was MTDad's (to the best of my recollection at the time of writing this) and licensed WTFPL.

Changelog:
v. 1.04 -code cleanup, all plants now spawn fully developed, more recipes to cover more farming redo items. JP's pumpkin replaces pumpkin slices.
v. 1.03 -added coffee, plus some small fixes.
v. 1.02 -converted to modpack, hud, diet, food, food_sweet support added, plus 3 recipes.
v. 1.01 -added whole potato planting for mtfoods compatibility plus minor texture fixes.

===FARMING_PLUS MOD for MINETEST===
by PilzAdam

License:
Sourcecode: WTFPL (see below)
Graphics: WTFPL (see below)

See also:
http://minetest.net/

         DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
                    Version 2, December 2004

 Copyright (C) 2004 Sam Hocevar <sam@hocevar.net>

 Everyone is permitted to copy and distribute verbatim or modified
 copies of this license document, and changing it is allowed as long
 as the name is changed.

            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION

  0. You just DO WHAT THE FUCK YOU WANT TO. 
