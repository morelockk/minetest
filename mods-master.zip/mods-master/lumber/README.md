Copyright (C) 2017 kakalak-lumberJack Jack Manning kakalak-lumberjack@gmail.com

This program is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public License as published by the Free Software Foundation; either version 2.1 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

License for Textures, Models and Sounds

CC-BY-SA 3.0 UNPORTED. Created/modified by Kakalak-lumberJack except as noted below:

color pallet derived from moretrees mod:
© 2013, Vanessa Ezekowitz <vanessaezekowitz@gmail.com>
	Published under the terms and conditions of CC-BY-SA-3.0 Unported.

