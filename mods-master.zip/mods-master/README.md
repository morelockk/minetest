This repository is a copy of mods used on a personal game server and is not intended to be a master version.
Several items herein are slightly adapted version of other people's great mods. Licenses should be found in their respective folder.
Some items are for my personal use, not officially intended for release. Any items not otherwise licensed should be considered licensed as WTFPL.
If its somehow useful to you, feel free to use it.
