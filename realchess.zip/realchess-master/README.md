A mod for Minetest to play a realistic chess game (GUI-based).

![Preview](https://i.imgur.com/xNwxC5Y.png)
