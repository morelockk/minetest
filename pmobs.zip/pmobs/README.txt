PMobs by CProgrammerRU

This mod uses the Mobs Redo Api to add new mobs to minetest.

0.1 - Added Npc, Guard, Ninja, Wolf, Dog and Yeti

Special thanks to TenPlus1.