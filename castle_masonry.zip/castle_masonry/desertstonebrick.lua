local desertstone = {{"desertstonebrick", "default:desert_stonebrick", "default_desert_stone_brick.png"},}
for i in ipairs(desertstone) do mdessto = desertstone[i][1] dessto = desertstone[i][2] tile = desertstone[i][3]

minetest.register_node("castle_masonry:arrowslit_"..mdessto,{
drawtype = "nodebox",
description = (mdessto.." Arrowslit"),
tiles = {tile},
groups = {cracky = 2, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",fixed = {{-0.5, -0.375, 0.5, -0.0625, 0.375, 0.3125},{0.0625, -0.375, 0.5, 0.5, 0.375, 0.3125},{-0.5, 0.375, 0.5, 0.5, 0.5, 0.3125}, {-0.5, -0.5, 0.5, 0.5, -0.375, 0.3125},{0.25, -0.5, 0.3125, 0.5, 0.5, 0.125},{-0.5, -0.5, 0.3125, -0.25, 0.5, 0.125},},},
})

minetest.register_node("castle_masonry:arrowslit_"..mdessto.."_cross",{
drawtype = "nodebox",
description = (mdessto.." Arrowslit with Cross"),
tiles = {tile},
groups = {cracky = 2, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, -0.125, 0.5, -0.0625, 0.375, 0.3125},{0.0625, -0.125, 0.5, 0.5, 0.375, 0.3125},{-0.5, 0.375, 0.5, 0.5, 0.5, 0.3125},{-0.5, -0.5, 0.5, 0.5, -0.375, 0.3125},{0.0625, -0.375, 0.5, 0.5, -0.25, 0.3125},{-0.5, -0.375, 0.5, -0.0625, -0.25, 0.3125},{-0.5, -0.25, 0.5, -0.1875, -0.125, 0.3125},{0.1875, -0.25, 0.5, 0.5, -0.125, 0.3125},{0.25, -0.5, 0.3125, 0.5, 0.5, 0.125},{-0.5, -0.5, 0.3125, -0.25, 0.5, 0.125},},},
})

minetest.register_node("castle_masonry:arrowslit_"..mdessto.."_hole",{
drawtype = "nodebox",
description = (mdessto.." Arrowslit with Hole"),
tiles = {tile},
groups = {cracky = 2, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, -0.375, 0.5, -0.125, 0.375, 0.3125},{0.125, -0.375, 0.5, 0.5, 0.375, 0.3125},{-0.5, -0.5, 0.5, 0.5, -0.375, 0.3125},{0.0625, -0.125, 0.5, 0.125, 0.375, 0.3125},{-0.125, -0.125, 0.5, -0.0625, 0.375, 0.3125},{-0.5, 0.375, 0.5, 0.5, 0.5, 0.3125},{0.25, -0.5, 0.3125, 0.5, 0.5, 0.125},{-0.5, -0.5, 0.3125, -0.25, 0.5, 0.125},},},
})

minetest.register_node("castle_masonry:arrowslit_"..mdessto.."_embrasure",{
drawtype = "nodebox",
description = (mdessto.." Embrasure"),
tiles = {tile},
groups = {cracky = 2, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.25, -0.5, 0.375, -0.125, 0.5, 0.5},{0.125, -0.5, 0.375, 0.25, 0.5, 0.5},{0.25, -0.5, 0.25, 0.5, 0.5, 0.5},{0.375, -0.5, 0.125, 0.5, 0.5, 0.25},{-0.5, -0.5, 0.25, -0.25, 0.5, 0.5},{-0.5, -0.5, 0.125, -0.375, 0.5, 0.25},},},
})

minetest.register_craft({output = "castle_masonry:arrowslit_"..mdessto.." 6",recipe ={{dessto,"",dessto},{dessto,"",dessto},{dessto,"",dessto}},})
minetest.register_craft({output = "castle_masonry:arrowslit_"..mdessto.."_cross",recipe = {{"castle_masonry:arrowslit_"..mdessto} },})
minetest.register_craft({output = "castle_masonry:arrowslit_"..mdessto.."_hole",recipe = {{"castle_masonry:arrowslit_"..mdessto.."_cross"} },})
minetest.register_craft({output = "castle_masonry:arrowslit_"..mdessto.."_embrasure",recipe = {{"castle_masonry:arrowslit_"..mdessto.."_hole"} },})

--murder_holes
minetest.register_node("castle_masonry:hole_"..mdessto,{
drawtype = "nodebox",
description = (mdessto.." with Murder Hole"),
tiles = {tile},
groups = {cracky = 2, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",fixed = {{-8/16,-8/16,-8/16,-4/16,8/16,8/16},{4/16,-8/16,-8/16,8/16,8/16,8/16},{-4/16,-8/16,-8/16,4/16,8/16,-4/16},{-4/16,-8/16,8/16,4/16,8/16,4/16},},},
})
	
minetest.register_node("castle_masonry:machicolation_"..mdessto,{
drawtype = "nodebox",
description = (mdessto.." with Machicolation"),
tiles = {tile},
groups = {cracky = 2, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",fixed = {{-0.5, 0, -0.5, 0.5, 0.5, 0},{-0.5, -0.5, 0, -0.25, 0.5, 0.5},{0.25, -0.5, 0, 0.5, 0.5, 0.5},},},
})

minetest.register_craft({output = "castle_masonry:hole_"..mdessto.." 4",recipe = {{"",dessto, ""},{dessto,"",dessto},{"",dessto, ""}},})
minetest.register_craft({output = "castle_masonry:machicolation_"..mdessto,type="shapeless",recipe = {"castle_masonry:hole_"..mdessto},})
minetest.register_craft({output = "castle_masonry:hole_"..mdessto,type="shapeless",recipe = {"castle_masonry:machicolation_"..mdessto},})
	
--pilars
minetest.register_node("castle_masonry:pillar_"..mdessto.."_bottom",{
drawtype = "nodebox",
description = (mdessto.." Pillar Base"),
tiles = {tile},
groups = {cracky = 2, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5,-0.5,-0.5,0.5,-0.375,0.5},{-0.375,-0.375,-0.375,0.375,-0.125,0.375},{-0.25,-0.125,-0.25,0.25,0.5,0.25}, },},
})

minetest.register_node("castle_masonry:pillar_"..mdessto.."_bottom_half",{
drawtype = "nodebox",
description = (mdessto.." Half Pillar Base"),
tiles = {tile},
groups = {cracky = 2, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, -0.5, 0, 0.5, -0.375, 0.5},{-0.375, -0.375, 0.125, 0.375, -0.125, 0.5},{-0.25, -0.125, 0.25, 0.25, 0.5, 0.5},},},
})

minetest.register_node("castle_masonry:pillar_"..mdessto.."_top",{
drawtype = "nodebox",
description = (mdessto.." Pillar Top"),
tiles = {tile},
groups = {cracky = 2, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5,0.3125,-0.5,0.5,0.5,0.5}, {-0.375,0.0625,-0.375,0.375,0.3125,0.375}, {-0.25,-0.5,-0.25,0.25,0.0625,0.25},},},
})

minetest.register_node("castle_masonry:pillar_"..mdessto.."_top_half",{
drawtype = "nodebox",
description = (mdessto.." Half Pillar Top"),
tiles = {tile},
groups = {cracky = 2, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, 0.3125, 0, 0.5, 0.5, 0.5},{-0.375, 0.0625, 0.125, 0.375, 0.3125, 0.5},{-0.25, -0.5, 0.25, 0.25, 0.0625, 0.5},},},
})	

minetest.register_node("castle_masonry:pillar_"..mdessto.."_middle",{
drawtype = "nodebox",
description = (mdessto.." Pillar Middle"),
tiles = {tile},
groups = {cracky = 2, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.25,-0.5,-0.25,0.25,0.5,0.25},},},
})

minetest.register_node("castle_masonry:pillar_"..mdessto.."_middle_half",{
drawtype = "nodebox",
description = (mdessto.." Half Pillar Middle"),
tiles = {tile},
groups = {cracky = 2, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.25, -0.5, 0.25, 0.25, 0.5, 0.5},},},
})

minetest.register_node("castle_masonry:pillar_"..mdessto.."_crossbrace",{
drawtype = "nodebox",
description = (mdessto.." Crossbrace"),
tiles = {tile},
groups = {cracky = 2, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "connected",
fixed = {-0.25,0.25,-0.25,0.25,0.5,0.25},connect_front = {-0.25,0.25,-0.75,0.25,0.5,-0.25}, connect_left = {-0.25,0.25,-0.25,-0.75,0.5,0.25}, connect_back = {-0.25,0.25,0.25,0.25,0.5,0.75},connect_right = {0.25,0.25,-0.25,0.75,0.5,0.25},},
connects_to = {"castle_masonry:pillar_"..mdessto.."_crossbrace","castle_masonry:pillar_"..mdessto.."_extended_crossbrace","group:crossbrace_connectable"},
connect_sides = { "front", "left", "back", "right" },
})

minetest.register_node("castle_masonry:pillar_"..mdessto.."_extended_crossbrace",{
drawtype = "nodebox",
description = (mdessto.." Extended Crossbrace"),
tiles = {tile},
groups = {cracky = 2, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {-1.25,0.25,-0.25,1.25,0.5,0.25},},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mdessto.."_bottom 4",
recipe = {{"",dessto,""},{"",dessto,""},{dessto,dessto,dessto}},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mdessto.."_top 4",
recipe = {{dessto,dessto,dessto},{"",dessto,""},{"",dessto,""}},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mdessto.."_middle 2",
recipe = {{dessto},{dessto},{dessto}},
})
	
minetest.register_craft({
output = "castle_masonry:pillar_"..mdessto.."_crossbrace 10",
recipe = {{dessto,"",dessto},{"",dessto,""},{dessto,"",dessto} },
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mdessto.."_middle_half 2",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mdessto.."_middle"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mdessto.."_middle",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mdessto.."_middle_half", "castle_masonry:pillar_"..mdessto.."_middle_half"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mdessto.."_top_half 2",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mdessto.."_top"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mdessto.."_top",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mdessto.."_top_half", "castle_masonry:pillar_"..mdessto.."_top_half"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mdessto.."_bottom_half 2",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mdessto.."_bottom"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mdessto.."_bottom",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mdessto.."_bottom_half", "castle_masonry:pillar_"..mdessto.."_bottom_half"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mdessto.."_extended_crossbrace",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mdessto.."_crossbrace"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mdessto.."_crossbrace",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mdessto.."_extended_crossbrace"},
})

end
