local obss = {{"obsidianbrick", "default:obsidianbrick", "default_obsidian_brick.png"},}
for i in ipairs(obss) do mobsbri = obss[i][1] obs = obss[i][2] tile = obss[i][3]

--arrowslit
minetest.register_node("castle_masonry:arrowslit_"..mobsbri,{
drawtype = "nodebox",
description = (mobsbri.." Arrowslit"),
tiles = {tile},
groups = {cracky = 1, level = 2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",fixed = {{-0.5, -0.375, 0.5, -0.0625, 0.375, 0.3125},{0.0625, -0.375, 0.5, 0.5, 0.375, 0.3125},{-0.5, 0.375, 0.5, 0.5, 0.5, 0.3125}, {-0.5, -0.5, 0.5, 0.5, -0.375, 0.3125},{0.25, -0.5, 0.3125, 0.5, 0.5, 0.125},{-0.5, -0.5, 0.3125, -0.25, 0.5, 0.125},},},
})

minetest.register_node("castle_masonry:arrowslit_"..mobsbri.."_cross",{
drawtype = "nodebox",
description = (mobsbri.." Arrowslit with Cross"),
tiles = {tile},
groups = {cracky = 1, level = 2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, -0.125, 0.5, -0.0625, 0.375, 0.3125},{0.0625, -0.125, 0.5, 0.5, 0.375, 0.3125},{-0.5, 0.375, 0.5, 0.5, 0.5, 0.3125},{-0.5, -0.5, 0.5, 0.5, -0.375, 0.3125},{0.0625, -0.375, 0.5, 0.5, -0.25, 0.3125},{-0.5, -0.375, 0.5, -0.0625, -0.25, 0.3125},{-0.5, -0.25, 0.5, -0.1875, -0.125, 0.3125},{0.1875, -0.25, 0.5, 0.5, -0.125, 0.3125},{0.25, -0.5, 0.3125, 0.5, 0.5, 0.125},{-0.5, -0.5, 0.3125, -0.25, 0.5, 0.125},},},
})

minetest.register_node("castle_masonry:arrowslit_"..mobsbri.."_hole",{
drawtype = "nodebox",
description = (mobsbri.." Arrowslit with Hole"),
tiles = {tile},
groups = {cracky = 1, level = 2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, -0.375, 0.5, -0.125, 0.375, 0.3125},{0.125, -0.375, 0.5, 0.5, 0.375, 0.3125},{-0.5, -0.5, 0.5, 0.5, -0.375, 0.3125},{0.0625, -0.125, 0.5, 0.125, 0.375, 0.3125},{-0.125, -0.125, 0.5, -0.0625, 0.375, 0.3125},{-0.5, 0.375, 0.5, 0.5, 0.5, 0.3125},{0.25, -0.5, 0.3125, 0.5, 0.5, 0.125},{-0.5, -0.5, 0.3125, -0.25, 0.5, 0.125},},},
})

minetest.register_node("castle_masonry:arrowslit_"..mobsbri.."_embrasure",{
drawtype = "nodebox",
description = (mobsbri.." Embrasure"),
tiles = {tile},
groups = {cracky = 1, level = 2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.25, -0.5, 0.375, -0.125, 0.5, 0.5},{0.125, -0.5, 0.375, 0.25, 0.5, 0.5},{0.25, -0.5, 0.25, 0.5, 0.5, 0.5},{0.375, -0.5, 0.125, 0.5, 0.5, 0.25},{-0.5, -0.5, 0.25, -0.25, 0.5, 0.5},{-0.5, -0.5, 0.125, -0.375, 0.5, 0.25},},},
})

minetest.register_craft({output = "castle_masonry:arrowslit_"..mobsbri.." 6",recipe ={{obs,"",obs},{obs,"",obs},{obs,"",obs}},})
minetest.register_craft({output = "castle_masonry:arrowslit_"..mobsbri.."_cross",recipe = {{"castle_masonry:arrowslit_"..mobsbri} },})
minetest.register_craft({output = "castle_masonry:arrowslit_"..mobsbri.."_hole",recipe = {{"castle_masonry:arrowslit_"..mobsbri.."_cross"} },})
minetest.register_craft({output = "castle_masonry:arrowslit_"..mobsbri.."_embrasure",recipe = {{"castle_masonry:arrowslit_"..mobsbri.."_hole"} },})

--murder_holes
minetest.register_node("castle_masonry:hole_"..mobsbri,{
drawtype = "nodebox",
description = (mobsbri.." with Murder Hole"),
tiles = {tile},
groups = {cracky = 1, level = 2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",fixed = {{-8/16,-8/16,-8/16,-4/16,8/16,8/16},{4/16,-8/16,-8/16,8/16,8/16,8/16},{-4/16,-8/16,-8/16,4/16,8/16,-4/16},{-4/16,-8/16,8/16,4/16,8/16,4/16},},},
})
	
minetest.register_node("castle_masonry:machicolation_"..mobsbri,{
drawtype = "nodebox",
description = (mobsbri.." with Machicolation"),
tiles = {tile},
groups = {cracky = 1, level = 2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",fixed = {{-0.5, 0, -0.5, 0.5, 0.5, 0},{-0.5, -0.5, 0, -0.25, 0.5, 0.5},{0.25, -0.5, 0, 0.5, 0.5, 0.5},},},
})

minetest.register_craft({output = "castle_masonry:hole_"..mobsbri.." 4",recipe = {{"",obs, ""},{obs,"",obs},{"",obs, ""}},})
minetest.register_craft({output = "castle_masonry:machicolation_"..mobsbri,type="shapeless",recipe = {"castle_masonry:hole_"..mobsbri},})
minetest.register_craft({output = "castle_masonry:hole_"..mobsbri,type="shapeless",recipe = {"castle_masonry:machicolation_"..mobsbri},})

--pilars
minetest.register_node("castle_masonry:pillar_"..mobsbri.."_bottom",{
drawtype = "nodebox",
description = (mobsbri.." Pillar Base"),
tiles = {tile},
groups = {cracky = 1, level = 2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5,-0.5,-0.5,0.5,-0.375,0.5},{-0.375,-0.375,-0.375,0.375,-0.125,0.375},{-0.25,-0.125,-0.25,0.25,0.5,0.25}, },},
})

minetest.register_node("castle_masonry:pillar_"..mobsbri.."_bottom_half",{
drawtype = "nodebox",
description = (mobsbri.." Half Pillar Base"),
tiles = {tile},
groups = {cracky = 1, level = 2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, -0.5, 0, 0.5, -0.375, 0.5},{-0.375, -0.375, 0.125, 0.375, -0.125, 0.5},{-0.25, -0.125, 0.25, 0.25, 0.5, 0.5},},},
})

minetest.register_node("castle_masonry:pillar_"..mobsbri.."_top",{
drawtype = "nodebox",
description = (mobsbri.." Pillar Top"),
tiles = {tile},
groups = {cracky = 1, level = 2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5,0.3125,-0.5,0.5,0.5,0.5}, {-0.375,0.0625,-0.375,0.375,0.3125,0.375}, {-0.25,-0.5,-0.25,0.25,0.0625,0.25},},},
})

minetest.register_node("castle_masonry:pillar_"..mobsbri.."_top_half",{
drawtype = "nodebox",
description = (mobsbri.." Half Pillar Top"),
tiles = {tile},
groups = {cracky = 1, level = 2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, 0.3125, 0, 0.5, 0.5, 0.5},{-0.375, 0.0625, 0.125, 0.375, 0.3125, 0.5},{-0.25, -0.5, 0.25, 0.25, 0.0625, 0.5},},},
})	

minetest.register_node("castle_masonry:pillar_"..mobsbri.."_middle",{
drawtype = "nodebox",
description = (mobsbri.." Pillar Middle"),
tiles = {tile},
groups = {cracky = 1, level = 2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.25,-0.5,-0.25,0.25,0.5,0.25},},},
})

minetest.register_node("castle_masonry:pillar_"..mobsbri.."_middle_half",{
drawtype = "nodebox",
description = (mobsbri.." Half Pillar Middle"),
tiles = {tile},
groups = {cracky = 1, level = 2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.25, -0.5, 0.25, 0.25, 0.5, 0.5},},},
})

minetest.register_node("castle_masonry:pillar_"..mobsbri.."_crossbrace",{
drawtype = "nodebox",
description = (mobsbri.." Crossbrace"),
tiles = {tile},
groups = {cracky = 1, level = 2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "connected",
fixed = {-0.25,0.25,-0.25,0.25,0.5,0.25},connect_front = {-0.25,0.25,-0.75,0.25,0.5,-0.25}, connect_left = {-0.25,0.25,-0.25,-0.75,0.5,0.25}, connect_back = {-0.25,0.25,0.25,0.25,0.5,0.75},connect_right = {0.25,0.25,-0.25,0.75,0.5,0.25},},
connects_to = {"castle_masonry:pillar_"..mobsbri.."_crossbrace","castle_masonry:pillar_"..mobsbri.."_extended_crossbrace","group:crossbrace_connectable"},
connect_sides = { "front", "left", "back", "right" },
})

minetest.register_node("castle_masonry:pillar_"..mobsbri.."_extended_crossbrace",{
drawtype = "nodebox",
description = (mobsbri.." Extended Crossbrace"),
tiles = {tile},
groups = {cracky = 1, level = 2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {-1.25,0.25,-0.25,1.25,0.5,0.25},},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mobsbri.."_bottom 4",
recipe = {{"",obs,""},{"",obs,""},{obs,obs,obs}},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mobsbri.."_top 4",
recipe = {{obs,obs,obs},{"",obs,""},{"",obs,""}},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mobsbri.."_middle 2",
recipe = {{obs},{obs},{obs}},
})
	
minetest.register_craft({
output = "castle_masonry:pillar_"..mobsbri.."_crossbrace 10",
recipe = {{obs,"",obs},{"",obs,""},{obs,"",obs} },
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mobsbri.."_middle_half 2",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mobsbri.."_middle"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mobsbri.."_middle",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mobsbri.."_middle_half", "castle_masonry:pillar_"..mobsbri.."_middle_half"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mobsbri.."_top_half 2",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mobsbri.."_top"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mobsbri.."_top",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mobsbri.."_top_half", "castle_masonry:pillar_"..mobsbri.."_top_half"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mobsbri.."_bottom_half 2",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mobsbri.."_bottom"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mobsbri.."_bottom",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mobsbri.."_bottom_half", "castle_masonry:pillar_"..mobsbri.."_bottom_half"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mobsbri.."_extended_crossbrace",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mobsbri.."_crossbrace"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mobsbri.."_crossbrace",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mobsbri.."_extended_crossbrace"},
})

end
