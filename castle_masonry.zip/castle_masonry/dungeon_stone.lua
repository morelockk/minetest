local duns = {{"dungeonstone", "castle_masonry:dungeon_stone", "castle_dungeon_stone.png"}}
for i in ipairs(duns) do mcaswall = duns[i][1] caswall = duns[i][2] tile = duns[i][3]
--arrowslit
minetest.register_node("castle_masonry:arrowslit_"..mcaswall,{
drawtype = "nodebox",
description = (mcaswall.." Arrowslit"),
tiles = {tile},
groups = {cracky=2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",fixed = {{-0.5, -0.375, 0.5, -0.0625, 0.375, 0.3125},{0.0625, -0.375, 0.5, 0.5, 0.375, 0.3125},{-0.5, 0.375, 0.5, 0.5, 0.5, 0.3125}, {-0.5, -0.5, 0.5, 0.5, -0.375, 0.3125},{0.25, -0.5, 0.3125, 0.5, 0.5, 0.125},{-0.5, -0.5, 0.3125, -0.25, 0.5, 0.125},},},
})

minetest.register_node("castle_masonry:arrowslit_"..mcaswall.."_cross",{
drawtype = "nodebox",
description = (mcaswall.." Arrowslit with Cross"),
tiles = {tile},
groups = {cracky=2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, -0.125, 0.5, -0.0625, 0.375, 0.3125},{0.0625, -0.125, 0.5, 0.5, 0.375, 0.3125},{-0.5, 0.375, 0.5, 0.5, 0.5, 0.3125},{-0.5, -0.5, 0.5, 0.5, -0.375, 0.3125},{0.0625, -0.375, 0.5, 0.5, -0.25, 0.3125},{-0.5, -0.375, 0.5, -0.0625, -0.25, 0.3125},{-0.5, -0.25, 0.5, -0.1875, -0.125, 0.3125},{0.1875, -0.25, 0.5, 0.5, -0.125, 0.3125},{0.25, -0.5, 0.3125, 0.5, 0.5, 0.125},{-0.5, -0.5, 0.3125, -0.25, 0.5, 0.125},},},
})

minetest.register_node("castle_masonry:arrowslit_"..mcaswall.."_hole",{
drawtype = "nodebox",
description = (mcaswall.." Arrowslit with Hole"),
tiles = {tile},
groups = {cracky=2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, -0.375, 0.5, -0.125, 0.375, 0.3125},{0.125, -0.375, 0.5, 0.5, 0.375, 0.3125},{-0.5, -0.5, 0.5, 0.5, -0.375, 0.3125},{0.0625, -0.125, 0.5, 0.125, 0.375, 0.3125},{-0.125, -0.125, 0.5, -0.0625, 0.375, 0.3125},{-0.5, 0.375, 0.5, 0.5, 0.5, 0.3125},{0.25, -0.5, 0.3125, 0.5, 0.5, 0.125},{-0.5, -0.5, 0.3125, -0.25, 0.5, 0.125},},},
})

minetest.register_node("castle_masonry:arrowslit_"..mcaswall.."_embrasure",{
drawtype = "nodebox",
description = (mcaswall.." Embrasure"),
tiles = {tile},
groups = {cracky=2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.25, -0.5, 0.375, -0.125, 0.5, 0.5},{0.125, -0.5, 0.375, 0.25, 0.5, 0.5},{0.25, -0.5, 0.25, 0.5, 0.5, 0.5},{0.375, -0.5, 0.125, 0.5, 0.5, 0.25},{-0.5, -0.5, 0.25, -0.25, 0.5, 0.5},{-0.5, -0.5, 0.125, -0.375, 0.5, 0.25},},},
})

minetest.register_craft({output = "castle_masonry:arrowslit_"..mcaswall.." 6",recipe ={{caswall,"",caswall},{caswall,"",caswall},{caswall,"",caswall}},})
minetest.register_craft({output = "castle_masonry:arrowslit_"..mcaswall.."_cross",recipe = {{"castle_masonry:arrowslit_"..mcaswall} },})
minetest.register_craft({output = "castle_masonry:arrowslit_"..mcaswall.."_hole",recipe = {{"castle_masonry:arrowslit_"..mcaswall.."_cross"} },})
minetest.register_craft({output = "castle_masonry:arrowslit_"..mcaswall.."_embrasure",recipe = {{"castle_masonry:arrowslit_"..mcaswall.."_hole"} },})

--murder_holes
minetest.register_node("castle_masonry:hole_"..mcaswall,{
drawtype = "nodebox",
description = (mcaswall.." with Murder Hole"),
tiles = {tile},
groups = {cracky=2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",fixed = {{-8/16,-8/16,-8/16,-4/16,8/16,8/16},{4/16,-8/16,-8/16,8/16,8/16,8/16},{-4/16,-8/16,-8/16,4/16,8/16,-4/16},{-4/16,-8/16,8/16,4/16,8/16,4/16},},},
})
	
minetest.register_node("castle_masonry:machicolation_"..mcaswall,{
drawtype = "nodebox",
description = (mcaswall.." with Machicolation"),
tiles = {tile},
groups = {cracky=2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",fixed = {{-0.5, 0, -0.5, 0.5, 0.5, 0},{-0.5, -0.5, 0, -0.25, 0.5, 0.5},{0.25, -0.5, 0, 0.5, 0.5, 0.5},},},
})

minetest.register_craft({output = "castle_masonry:hole_"..mcaswall.." 4",recipe = {{"",caswall, ""},{caswall,"",caswall},{"",caswall, ""}},})
minetest.register_craft({output = "castle_masonry:machicolation_"..mcaswall,type="shapeless",recipe = {"castle_masonry:hole_"..mcaswall},})
minetest.register_craft({output = "castle_masonry:hole_"..mcaswall,type="shapeless",recipe = {"castle_masonry:machicolation_"..mcaswall},})	

--pilars
minetest.register_node("castle_masonry:pillar_"..mcaswall.."_bottom",{
drawtype = "nodebox",
description = (mcaswall.." Pillar Base"),
tiles = {tile},
groups = {cracky=2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5,-0.5,-0.5,0.5,-0.375,0.5},{-0.375,-0.375,-0.375,0.375,-0.125,0.375},{-0.25,-0.125,-0.25,0.25,0.5,0.25}, },},
})

minetest.register_node("castle_masonry:pillar_"..mcaswall.."_bottom_half",{
drawtype = "nodebox",
description = (mcaswall.." Half Pillar Base"),
tiles = {tile},
groups = {cracky=2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, -0.5, 0, 0.5, -0.375, 0.5},{-0.375, -0.375, 0.125, 0.375, -0.125, 0.5},{-0.25, -0.125, 0.25, 0.25, 0.5, 0.5},},},
})

minetest.register_node("castle_masonry:pillar_"..mcaswall.."_top",{
drawtype = "nodebox",
description = (mcaswall.." Pillar Top"),
tiles = {tile},
groups = {cracky=2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5,0.3125,-0.5,0.5,0.5,0.5}, {-0.375,0.0625,-0.375,0.375,0.3125,0.375}, {-0.25,-0.5,-0.25,0.25,0.0625,0.25},},},
})

minetest.register_node("castle_masonry:pillar_"..mcaswall.."_top_half",{
drawtype = "nodebox",
description = (mcaswall.." Half Pillar Top"),
tiles = {tile},
groups = {cracky=2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, 0.3125, 0, 0.5, 0.5, 0.5},{-0.375, 0.0625, 0.125, 0.375, 0.3125, 0.5},{-0.25, -0.5, 0.25, 0.25, 0.0625, 0.5},},},
})	

minetest.register_node("castle_masonry:pillar_"..mcaswall.."_middle",{
drawtype = "nodebox",
description = (mcaswall.." Pillar Middle"),
tiles = {tile},
groups = {cracky=2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.25,-0.5,-0.25,0.25,0.5,0.25},},},
})

minetest.register_node("castle_masonry:pillar_"..mcaswall.."_middle_half",{
drawtype = "nodebox",
description = (mcaswall.." Half Pillar Middle"),
tiles = {tile},
groups = {cracky=2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.25, -0.5, 0.25, 0.25, 0.5, 0.5},},},
})

minetest.register_node("castle_masonry:pillar_"..mcaswall.."_crossbrace",{
drawtype = "nodebox",
description = (mcaswall.." Crossbrace"),
tiles = {tile},
groups = {cracky=2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "connected",
fixed = {-0.25,0.25,-0.25,0.25,0.5,0.25},connect_front = {-0.25,0.25,-0.75,0.25,0.5,-0.25}, connect_left = {-0.25,0.25,-0.25,-0.75,0.5,0.25}, connect_back = {-0.25,0.25,0.25,0.25,0.5,0.75},connect_right = {0.25,0.25,-0.25,0.75,0.5,0.25},},
connects_to = {"castle_masonry:pillar_"..mcaswall.."_crossbrace","castle_masonry:pillar_"..mcaswall.."_extended_crossbrace","group:crossbrace_connectable"},
connect_sides = { "front", "left", "back", "right" },
})

minetest.register_node("castle_masonry:pillar_"..mcaswall.."_extended_crossbrace",{
drawtype = "nodebox",
description = (mcaswall.." Extended Crossbrace"),
tiles = {tile},
groups = {cracky=2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {-1.25,0.25,-0.25,1.25,0.5,0.25},},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mcaswall.."_bottom 4",
recipe = {{"",caswall,""},{"",caswall,""},{caswall,caswall,caswall}},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mcaswall.."_top 4",
recipe = {{caswall,caswall,caswall},{"",caswall,""},{"",caswall,""}},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mcaswall.."_middle 2",
recipe = {{caswall},{caswall},{caswall}},
})
	
minetest.register_craft({
output = "castle_masonry:pillar_"..mcaswall.."_crossbrace 10",
recipe = {{caswall,"",caswall},{"",caswall,""},{caswall,"",caswall} },
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mcaswall.."_middle_half 2",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mcaswall.."_middle"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mcaswall.."_middle",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mcaswall.."_middle_half", "castle_masonry:pillar_"..mcaswall.."_middle_half"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mcaswall.."_top_half 2",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mcaswall.."_top"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mcaswall.."_top",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mcaswall.."_top_half", "castle_masonry:pillar_"..mcaswall.."_top_half"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mcaswall.."_bottom_half 2",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mcaswall.."_bottom"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mcaswall.."_bottom",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mcaswall.."_bottom_half", "castle_masonry:pillar_"..mcaswall.."_bottom_half"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mcaswall.."_extended_crossbrace",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mcaswall.."_crossbrace"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mcaswall.."_crossbrace",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mcaswall.."_extended_crossbrace"},
})

end
