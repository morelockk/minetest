local stones = {{"cobble", "default:cobble", "default_cobble.png"},}
for i in ipairs(stones) do mstone = stones[i][1] stone = stones[i][2] tile = stones[i][3]

--arrowslit
minetest.register_node("castle_masonry:arrowslit_"..mstone,{
drawtype = "nodebox",
description = (mstone.." Arrowslit"),
tiles = {tile},
groups = {cracky = 3, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",fixed = {{-0.5, -0.375, 0.5, -0.0625, 0.375, 0.3125},{0.0625, -0.375, 0.5, 0.5, 0.375, 0.3125},{-0.5, 0.375, 0.5, 0.5, 0.5, 0.3125}, {-0.5, -0.5, 0.5, 0.5, -0.375, 0.3125},{0.25, -0.5, 0.3125, 0.5, 0.5, 0.125},{-0.5, -0.5, 0.3125, -0.25, 0.5, 0.125},},},
})

minetest.register_node("castle_masonry:arrowslit_"..mstone.."_cross",{
drawtype = "nodebox",
description = (mstone.." Arrowslit with Cross"),
tiles = {tile},
groups = {cracky = 3, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, -0.125, 0.5, -0.0625, 0.375, 0.3125},{0.0625, -0.125, 0.5, 0.5, 0.375, 0.3125},{-0.5, 0.375, 0.5, 0.5, 0.5, 0.3125},{-0.5, -0.5, 0.5, 0.5, -0.375, 0.3125},{0.0625, -0.375, 0.5, 0.5, -0.25, 0.3125},{-0.5, -0.375, 0.5, -0.0625, -0.25, 0.3125},{-0.5, -0.25, 0.5, -0.1875, -0.125, 0.3125},{0.1875, -0.25, 0.5, 0.5, -0.125, 0.3125},{0.25, -0.5, 0.3125, 0.5, 0.5, 0.125},{-0.5, -0.5, 0.3125, -0.25, 0.5, 0.125},},},
})

minetest.register_node("castle_masonry:arrowslit_"..mstone.."_hole",{
drawtype = "nodebox",
description = (mstone.." Arrowslit with Hole"),
tiles = {tile},
groups = {cracky = 3, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, -0.375, 0.5, -0.125, 0.375, 0.3125},{0.125, -0.375, 0.5, 0.5, 0.375, 0.3125},{-0.5, -0.5, 0.5, 0.5, -0.375, 0.3125},{0.0625, -0.125, 0.5, 0.125, 0.375, 0.3125},{-0.125, -0.125, 0.5, -0.0625, 0.375, 0.3125},{-0.5, 0.375, 0.5, 0.5, 0.5, 0.3125},{0.25, -0.5, 0.3125, 0.5, 0.5, 0.125},{-0.5, -0.5, 0.3125, -0.25, 0.5, 0.125},},},
})

minetest.register_node("castle_masonry:arrowslit_"..mstone.."_embrasure",{
drawtype = "nodebox",
description = (mstone.." Embrasure"),
tiles = {tile},
groups = {cracky = 3, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.25, -0.5, 0.375, -0.125, 0.5, 0.5},{0.125, -0.5, 0.375, 0.25, 0.5, 0.5},{0.25, -0.5, 0.25, 0.5, 0.5, 0.5},{0.375, -0.5, 0.125, 0.5, 0.5, 0.25},{-0.5, -0.5, 0.25, -0.25, 0.5, 0.5},{-0.5, -0.5, 0.125, -0.375, 0.5, 0.25},},},
})

minetest.register_craft({output = "castle_masonry:arrowslit_"..mstone.." 6",recipe ={{stone,"",stone},{stone,"",stone},{stone,"",stone}},})
minetest.register_craft({output = "castle_masonry:arrowslit_"..mstone.."_cross",recipe = {{"castle_masonry:arrowslit_"..mstone} },})
minetest.register_craft({output = "castle_masonry:arrowslit_"..mstone.."_hole",recipe = {{"castle_masonry:arrowslit_"..mstone.."_cross"} },})
minetest.register_craft({output = "castle_masonry:arrowslit_"..mstone.."_embrasure",recipe = {{"castle_masonry:arrowslit_"..mstone.."_hole"} },})

--murder_holes
minetest.register_node("castle_masonry:hole_"..mstone,{
drawtype = "nodebox",
description = (mstone.." Murder Hole"),
tiles = {tile},
groups = {cracky = 3, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",fixed = {{-8/16,-8/16,-8/16,-4/16,8/16,8/16},{4/16,-8/16,-8/16,8/16,8/16,8/16},{-4/16,-8/16,-8/16,4/16,8/16,-4/16},{-4/16,-8/16,8/16,4/16,8/16,4/16},},},
})
	
minetest.register_node("castle_masonry:machicolation_"..mstone,{
drawtype = "nodebox",
description = (mstone.." Machicolation"),
tiles = {tile},
groups = {cracky = 3, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",fixed = {{-0.5, 0, -0.5, 0.5, 0.5, 0},{-0.5, -0.5, 0, -0.25, 0.5, 0.5},{0.25, -0.5, 0, 0.5, 0.5, 0.5},},},
})

minetest.register_craft({output = "castle_masonry:hole_"..mstone.." 4",recipe = {{"",stone, ""},{stone,"",stone},{"",stone, ""}},})
minetest.register_craft({output = "castle_masonry:machicolation_"..mstone,type="shapeless",recipe = {"castle_masonry:hole_"..mstone},})
minetest.register_craft({output = "castle_masonry:hole_"..mstone,type="shapeless",recipe = {"castle_masonry:machicolation_"..mstone},})

if minetest.get_modpath("moreblocks") then
stairsplus:register_all("castle", "pavement_brick", "castle_masonry:pavement_brick", {
description = (" Pavement Brick"),
tiles = {"castle_pavement_brick.png"},
groups = {cracky=2, not_in_creative_inventory=1},
sounds = default.node_sound_stone_defaults(),
sunlight_propagates = true,
})
elseif minetest.get_modpath("stairs") then
stairs.register_stair_and_slab("pavement_brick", "castle_masonry:pavement_brick",
{cracky=2},
{"castle_pavement_brick.png"},
("Castle Pavement Stair"),
("Castle Pavement Slab"),
default.node_sound_stone_defaults()
)
end

minetest.register_node("castle_masonry:roofslate",{
drawtype = "raillike",
description = (" Roof Slates"),
inventory_image = "castle_slate.png",
paramtype = "light",
walkable = false,
tiles = {'castle_slate.png'},
climbable = true,
selection_box = {type = "fixed",fixed = {-1/2, -1/2, -1/2, 1/2, -1/2+1/16, 1/2},},
groups = {cracky=3,attached_node=1},
sounds = default.node_sound_stone_defaults(),
})

if minetest.get_modpath("moreblocks") then
minetest.register_craft({
output = "castle_masonry:roofslate 4",
recipe = {{ "building_blocks:Tar" , "default:gravel" },{ "default:gravel",       "building_blocks:Tar" }}
})

minetest.register_craft({
output = "castle_masonry:roofslate 4",
recipe = {{ "default:gravel",       "building_blocks:Tar" },{ "building_blocks:Tar" , "default:gravel" }}
})
end

if minetest.get_modpath("streets") then
minetest.register_craft({
output = "castle_masonry:roofslate 4",
recipe = {{ "streets:asphalt" , "default:gravel" },{ "default:gravel",   "streets:asphalt" }}
})

minetest.register_craft({
output = "castle_masonry:roofslate 4",
recipe = {{ "default:gravel",   "streets:asphalt" },{ "streets:asphalt" , "default:gravel" }}
})
end

if minetest.get_modpath("building_blocks") or minetest.get_modpath("streets") then
minetest.register_craft({
type = "cooking",
output = "castle_masonry:roofslate",
recipe = "default:gravel",
})
end

--pilars
minetest.register_node("castle_masonry:pillar_"..mstone.."_bottom",{
drawtype = "nodebox",
description = (mstone.." Pillar Base"),
tiles = {tile},
groups = {cracky = 3, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5,-0.5,-0.5,0.5,-0.375,0.5},{-0.375,-0.375,-0.375,0.375,-0.125,0.375},{-0.25,-0.125,-0.25,0.25,0.5,0.25}, },},
})

minetest.register_node("castle_masonry:pillar_"..mstone.."_bottom_half",{
drawtype = "nodebox",
description = (mstone.." Half Pillar Base"),
tiles = {tile},
groups = {cracky = 3, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, -0.5, 0, 0.5, -0.375, 0.5},{-0.375, -0.375, 0.125, 0.375, -0.125, 0.5},{-0.25, -0.125, 0.25, 0.25, 0.5, 0.5},},},
})

minetest.register_node("castle_masonry:pillar_"..mstone.."_top",{
drawtype = "nodebox",
description = (mstone.." Pillar Top"),
tiles = {tile},
groups = {cracky = 3, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5,0.3125,-0.5,0.5,0.5,0.5}, {-0.375,0.0625,-0.375,0.375,0.3125,0.375}, {-0.25,-0.5,-0.25,0.25,0.0625,0.25},},},
})

minetest.register_node("castle_masonry:pillar_"..mstone.."_top_half",{
drawtype = "nodebox",
description = (mstone.." Half Pillar Top"),
tiles = {tile},
groups = {cracky = 3, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, 0.3125, 0, 0.5, 0.5, 0.5},{-0.375, 0.0625, 0.125, 0.375, 0.3125, 0.5},{-0.25, -0.5, 0.25, 0.25, 0.0625, 0.5},},},
})	

minetest.register_node("castle_masonry:pillar_"..mstone.."_middle",{
drawtype = "nodebox",
description = (mstone.." Pillar Middle"),
tiles = {tile},
groups = {cracky = 3, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.25,-0.5,-0.25,0.25,0.5,0.25},},},
})

minetest.register_node("castle_masonry:pillar_"..mstone.."_middle_half",{
drawtype = "nodebox",
description = (mstone.." Half Pillar Middle"),
tiles = {tile},
groups = {cracky = 3, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.25, -0.5, 0.25, 0.25, 0.5, 0.5},},},
})

minetest.register_node("castle_masonry:pillar_"..mstone.."_crossbrace",{
drawtype = "nodebox",
description = (mstone.." Crossbrace"),
tiles = {tile},
groups = {cracky = 3, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "connected",
fixed = {-0.25,0.25,-0.25,0.25,0.5,0.25},connect_front = {-0.25,0.25,-0.75,0.25,0.5,-0.25}, connect_left = {-0.25,0.25,-0.25,-0.75,0.5,0.25}, connect_back = {-0.25,0.25,0.25,0.25,0.5,0.75},connect_right = {0.25,0.25,-0.25,0.75,0.5,0.25},},
connects_to = {"castle_masonry:pillar_"..mstone.."_crossbrace","castle_masonry:pillar_"..mstone.."_extended_crossbrace","group:crossbrace_connectable"},
connect_sides = { "front", "left", "back", "right" },
})

minetest.register_node("castle_masonry:pillar_"..mstone.."_extended_crossbrace",{
drawtype = "nodebox",
description = (mstone.." Extended Crossbrace"),
tiles = {tile},
groups = {cracky = 3, stone = 1},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {-1.25,0.25,-0.25,1.25,0.5,0.25},},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mstone.."_bottom 4",
recipe = {{"",stone,""},{"",stone,""},{stone,stone,stone}},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mstone.."_top 4",
recipe = {{stone,stone,stone},{"",stone,""},{"",stone,""}},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mstone.."_middle 2",
recipe = {{stone},{stone},{stone} },
})
	
minetest.register_craft({
output = "castle_masonry:pillar_"..mstone.."_crossbrace 10",
recipe = {{stone,"",stone},{"",stone,""},{stone,"",stone} },
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mstone.."_middle_half 2",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mstone.."_middle"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mstone.."_middle",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mstone.."_middle_half", "castle_masonry:pillar_"..mstone.."_middle_half"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mstone.."_top_half 2",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mstone.."_top"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mstone.."_top",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mstone.."_top_half", "castle_masonry:pillar_"..mstone.."_top_half"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mstone.."_bottom_half 2",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mstone.."_bottom"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mstone.."_bottom",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mstone.."_bottom_half", "castle_masonry:pillar_"..mstone.."_bottom_half"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mstone.."_extended_crossbrace",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mstone.."_crossbrace"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mstone.."_crossbrace",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mstone.."_extended_crossbrace"},
})

--stone wall
minetest.register_node("castle_masonry:stonewall",{
description = ("Castle Wall"),
drawtype = "normal",
tiles = {"castle_stonewall.png"},
paramtype = "light",
drop = "castle_masonry:stonewall",
groups = {cracky=3},
sunlight_propagates = false,
sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("castle_masonry:rubble",{
description = ("Castle Rubble"),
drawtype = "normal",
tiles = {"castle_rubble.png"},
paramtype = "light",
groups = {crumbly=3,falling_node=1},
sounds = default.node_sound_gravel_defaults(),
})

minetest.register_craft({
output = "castle_masonry:stonewall",
recipe = {{"default:cobble"},{"default:desert_stone"},}
})

minetest.register_craft({
output = "castle_masonry:rubble",
recipe = {{"castle_masonry:stonewall"},}
})

minetest.register_craft({
output = "castle_masonry:rubble 2",
recipe = {{"default:gravel"},{"default:desert_stone"},}
})

minetest.register_node("castle_masonry:stonewall_corner",{
drawtype = "normal",
paramtype = "light",
paramtype2 = "facedir",
description = ("Castle Corner"),
tiles = {"castle_corner_stonewall_tb.png^[transformR90","castle_corner_stonewall_tb.png^[transformR180","castle_corner_stonewall1.png","castle_stonewall.png","castle_stonewall.png","castle_corner_stonewall2.png"},
groups = {cracky=3},
sounds = default.node_sound_stone_defaults(),
})

minetest.register_craft({
output = "castle_masonry:stonewall_corner",
recipe = {{"", "castle_masonry:stonewall"},{"castle_masonry:stonewall", "default:sandstone"},}
})

end
