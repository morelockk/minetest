local ices = {{"snow", "default:snowblock", "default_snow.png",{crumbly=3,puts_out_fire=1,cools_lava=1,snowy=1}},}
for i in ipairs(ices) do mices = ices[i][1] isn = ices[i][2] tile = ices[i][3] gices= ices[i][4]
--arrowslit
minetest.register_node("castle_masonry:arrowslit_"..mices,{
drawtype = "nodebox",
description = (mices.." Arrowslit"),
tiles = {tile},
groups = {gices},
sounds = default.node_sound_dirt_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {
type = "fixed",
fixed = {
{-0.5, -0.375, 0.5, -0.0625, 0.375, 0.3125},
{0.0625, -0.375, 0.5, 0.5, 0.375, 0.3125},
{-0.5, 0.375, 0.5, 0.5, 0.5, 0.3125},
{-0.5, -0.5, 0.5, 0.5, -0.375, 0.3125},
{0.25, -0.5, 0.3125, 0.5, 0.5, 0.125},
{-0.5, -0.5, 0.3125, -0.25, 0.5, 0.125}}}
})

minetest.register_node("castle_masonry:arrowslit_"..mices.."_cross",{
drawtype = "nodebox",
description = (mices.." Arrowslit with Cross"),
tiles = {tile},
groups = {crumbly = 3, puts_out_fire = 1, cools_lava = 1, snowy = 1},
sounds = default.node_sound_dirt_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, -0.125, 0.5, -0.0625, 0.375, 0.3125},{0.0625, -0.125, 0.5, 0.5, 0.375, 0.3125},{-0.5, 0.375, 0.5, 0.5, 0.5, 0.3125},{-0.5, -0.5, 0.5, 0.5, -0.375, 0.3125},{0.0625, -0.375, 0.5, 0.5, -0.25, 0.3125},{-0.5, -0.375, 0.5, -0.0625, -0.25, 0.3125},{-0.5, -0.25, 0.5, -0.1875, -0.125, 0.3125},{0.1875, -0.25, 0.5, 0.5, -0.125, 0.3125},{0.25, -0.5, 0.3125, 0.5, 0.5, 0.125},{-0.5, -0.5, 0.3125, -0.25, 0.5, 0.125},},},
})

minetest.register_node("castle_masonry:arrowslit_"..mices.."_hole",{
drawtype = "nodebox",
description = (mices.." Arrowslit of Desert Sandstone with Hole"),
tiles = {tile},
groups = {crumbly = 3, puts_out_fire = 1, cools_lava = 1, snowy = 1},
sounds = default.node_sound_dirt_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, -0.375, 0.5, -0.125, 0.375, 0.3125},{0.125, -0.375, 0.5, 0.5, 0.375, 0.3125},{-0.5, -0.5, 0.5, 0.5, -0.375, 0.3125},{0.0625, -0.125, 0.5, 0.125, 0.375, 0.3125},{-0.125, -0.125, 0.5, -0.0625, 0.375, 0.3125},{-0.5, 0.375, 0.5, 0.5, 0.5, 0.3125},{0.25, -0.5, 0.3125, 0.5, 0.5, 0.125},{-0.5, -0.5, 0.3125, -0.25, 0.5, 0.125},},},
})

minetest.register_node("castle_masonry:arrowslit_"..mices.."_embrasure",{
drawtype = "nodebox",
description = (mices.." Embrasure"),
tiles = {tile},
groups = {crumbly = 3, puts_out_fire = 1, cools_lava = 1, snowy = 1},
sounds = default.node_sound_dirt_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.25, -0.5, 0.375, -0.125, 0.5, 0.5},{0.125, -0.5, 0.375, 0.25, 0.5, 0.5},{0.25, -0.5, 0.25, 0.5, 0.5, 0.5},{0.375, -0.5, 0.125, 0.5, 0.5, 0.25},{-0.5, -0.5, 0.25, -0.25, 0.5, 0.5},{-0.5, -0.5, 0.125, -0.375, 0.5, 0.25},},},
})

minetest.register_craft({output = "castle_masonry:arrowslit_"..mices.." 6",recipe ={{isn,"",isn},{isn,"",isn},{isn,"",isn}},})
minetest.register_craft({output = "castle_masonry:arrowslit_"..mices.."_cross",recipe = {{"castle_masonry:arrowslit_"..mices} },})
minetest.register_craft({output = "castle_masonry:arrowslit_"..mices.."_hole",recipe = {{"castle_masonry:arrowslit_"..mices.."_cross"} },})
minetest.register_craft({output = "castle_masonry:arrowslit_"..mices.."_embrasure",recipe = {{"castle_masonry:arrowslit_"..mices.."_hole"} },})

--murder_holes
minetest.register_node("castle_masonry:hole_"..mices,{
drawtype = "nodebox",
description = (mices.." with Murder Hole"),
tiles = {tile},
groups = {crumbly = 3, puts_out_fire = 1, cools_lava = 1, snowy = 1},
sounds = default.node_sound_dirt_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",fixed = {{-8/16,-8/16,-8/16,-4/16,8/16,8/16},{4/16,-8/16,-8/16,8/16,8/16,8/16},{-4/16,-8/16,-8/16,4/16,8/16,-4/16},{-4/16,-8/16,8/16,4/16,8/16,4/16},},},
})
	
minetest.register_node("castle_masonry:machicolation_"..mices,{
drawtype = "nodebox",
description = (mices.." with Machicolation"),
tiles = {tile},
groups = {crumbly = 3, puts_out_fire = 1, cools_lava = 1, snowy = 1},
sounds = default.node_sound_dirt_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",fixed = {{-0.5, 0, -0.5, 0.5, 0.5, 0},{-0.5, -0.5, 0, -0.25, 0.5, 0.5},{0.25, -0.5, 0, 0.5, 0.5, 0.5},},},
})

minetest.register_craft({output = "castle_masonry:hole_"..mices.." 4",recipe = {{"",isn, ""},{isn,"",isn},{"",isn, ""}},})
minetest.register_craft({output = "castle_masonry:machicolation_"..mices,type="shapeless",recipe = {"castle_masonry:hole_"..mices},})
minetest.register_craft({output = "castle_masonry:hole_"..mices,type="shapeless",recipe = {"castle_masonry:machicolation_"..mices},})

--pilars
minetest.register_node("castle_masonry:pillar_"..mices.."_bottom",{
drawtype = "nodebox",
description = (mices.." Pillar Base"),
tiles = {tile},
groups = {crumbly = 3, puts_out_fire = 1, cools_lava = 1, snowy = 1},
sounds = default.node_sound_dirt_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5,-0.5,-0.5,0.5,-0.375,0.5},{-0.375,-0.375,-0.375,0.375,-0.125,0.375},{-0.25,-0.125,-0.25,0.25,0.5,0.25}, },},
})

minetest.register_node("castle_masonry:pillar_"..mices.."_bottom_half",{
drawtype = "nodebox",
description = (mices.." Half Pillar Base"),
tiles = {tile},
groups = {crumbly = 3, puts_out_fire = 1, cools_lava = 1, snowy = 1},
sounds = default.node_sound_dirt_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, -0.5, 0, 0.5, -0.375, 0.5},{-0.375, -0.375, 0.125, 0.375, -0.125, 0.5},{-0.25, -0.125, 0.25, 0.25, 0.5, 0.5},},},
})

minetest.register_node("castle_masonry:pillar_"..mices.."_top",{
drawtype = "nodebox",
description = (mices.." Pillar Top"),
tiles = {tile},
groups = {crumbly = 3, puts_out_fire = 1, cools_lava = 1, snowy = 1},
sounds = default.node_sound_dirt_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5,0.3125,-0.5,0.5,0.5,0.5}, {-0.375,0.0625,-0.375,0.375,0.3125,0.375}, {-0.25,-0.5,-0.25,0.25,0.0625,0.25},},},
})

minetest.register_node("castle_masonry:pillar_"..mices.."_top_half",{
drawtype = "nodebox",
description = (mices.." Half Pillar Top"),
tiles = {tile},
groups = {crumbly = 3, puts_out_fire = 1, cools_lava = 1, snowy = 1},
sounds = default.node_sound_dirt_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, 0.3125, 0, 0.5, 0.5, 0.5},{-0.375, 0.0625, 0.125, 0.375, 0.3125, 0.5},{-0.25, -0.5, 0.25, 0.25, 0.0625, 0.5},},},
})	

minetest.register_node("castle_masonry:pillar_"..mices.."_middle",{
drawtype = "nodebox",
description = (mices.." Pillar Middle"),
tiles = {tile},
groups = {crumbly = 3, puts_out_fire = 1, cools_lava = 1, snowy = 1},
sounds = default.node_sound_dirt_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.25,-0.5,-0.25,0.25,0.5,0.25},},},
})

minetest.register_node("castle_masonry:pillar_"..mices.."_middle_half",{
drawtype = "nodebox",
description = (mices.." Half Pillar Middle"),
tiles = {tile},
groups = {crumbly = 3, puts_out_fire = 1, cools_lava = 1, snowy = 1},
sounds = default.node_sound_dirt_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.25, -0.5, 0.25, 0.25, 0.5, 0.5},},},
})

minetest.register_node("castle_masonry:pillar_"..mices.."_crossbrace",{
drawtype = "nodebox",
description = (mices.." Crossbrace"),
tiles = {tile},
groups = {crumbly = 3, puts_out_fire = 1, cools_lava = 1, snowy = 1},
sounds = default.node_sound_dirt_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "connected",
fixed = {-0.25,0.25,-0.25,0.25,0.5,0.25},connect_front = {-0.25,0.25,-0.75,0.25,0.5,-0.25}, connect_left = {-0.25,0.25,-0.25,-0.75,0.5,0.25}, connect_back = {-0.25,0.25,0.25,0.25,0.5,0.75},connect_right = {0.25,0.25,-0.25,0.75,0.5,0.25},},
connects_to = {"castle_masonry:pillar_"..mices.."_crossbrace","castle_masonry:pillar_"..mices.."_extended_crossbrace","group:crossbrace_connectable"},
connect_sides = { "front", "left", "back", "right" },
})

minetest.register_node("castle_masonry:pillar_"..mices.."_extended_crossbrace",{
drawtype = "nodebox",
description = (mices.." Extended Crossbrace"),
tiles = {tile},
groups = {crumbly = 3, puts_out_fire = 1, cools_lava = 1, snowy = 1},
sounds = default.node_sound_dirt_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {-1.25,0.25,-0.25,1.25,0.5,0.25},},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mices.."_bottom 4",
recipe = {{"",isn,""},{"",isn,""},{isn,isn,isn}},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mices.."_top 4",
recipe = {{isn,isn,isn},{"",isn,""},{"",isn,""}},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mices.."_middle 2",
recipe = {{isn},{isn},{isn}},
})
	
minetest.register_craft({
output = "castle_masonry:pillar_"..mices.."_crossbrace 10",
recipe = {{isn,"",isn},{"",isn,""},{isn,"",isn} },
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mices.."_middle_half 2",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mices.."_middle"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mices.."_middle",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mices.."_middle_half", "castle_masonry:pillar_"..mices.."_middle_half"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mices.."_top_half 2",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mices.."_top"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mices.."_top",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mices.."_top_half", "castle_masonry:pillar_"..mices.."_top_half"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mices.."_bottom_half 2",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mices.."_bottom"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mices.."_bottom",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mices.."_bottom_half", "castle_masonry:pillar_"..mices.."_bottom_half"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mices.."_extended_crossbrace",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mices.."_crossbrace"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mices.."_crossbrace",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mices.."_extended_crossbrace"},
})

end
