local woods = {{"pinewood", "default:pine_wood", "default_pine_wood.png"},}
for i in ipairs(woods) do mwood = woods[i][1] wood = woods[i][2]  tile = woods[i][3]
--arrowslit
minetest.register_node("castle_masonry:arrowslit_"..mwood,{
drawtype = "nodebox",
description = (mwood.." Arrowslit"),
tiles = {tile},
groups = {choppy = 3, oddly_breakable_by_hand = 2, wood = 1},
sounds = default.node_sound_wood_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",fixed = {{-0.5, -0.375, 0.5, -0.0625, 0.375, 0.3125},{0.0625, -0.375, 0.5, 0.5, 0.375, 0.3125},{-0.5, 0.375, 0.5, 0.5, 0.5, 0.3125}, {-0.5, -0.5, 0.5, 0.5, -0.375, 0.3125},{0.25, -0.5, 0.3125, 0.5, 0.5, 0.125},{-0.5, -0.5, 0.3125, -0.25, 0.5, 0.125},},},
})

minetest.register_node("castle_masonry:arrowslit_"..mwood.."_cross",{
drawtype = "nodebox",
description = (mwood.." Arrowslit with Cross"),
tiles = {tile},
groups = {choppy = 3, oddly_breakable_by_hand = 2, wood = 1},
sounds = default.node_sound_wood_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, -0.125, 0.5, -0.0625, 0.375, 0.3125},{0.0625, -0.125, 0.5, 0.5, 0.375, 0.3125},{-0.5, 0.375, 0.5, 0.5, 0.5, 0.3125},{-0.5, -0.5, 0.5, 0.5, -0.375, 0.3125},{0.0625, -0.375, 0.5, 0.5, -0.25, 0.3125},{-0.5, -0.375, 0.5, -0.0625, -0.25, 0.3125},{-0.5, -0.25, 0.5, -0.1875, -0.125, 0.3125},{0.1875, -0.25, 0.5, 0.5, -0.125, 0.3125},{0.25, -0.5, 0.3125, 0.5, 0.5, 0.125},{-0.5, -0.5, 0.3125, -0.25, 0.5, 0.125},},},
})

minetest.register_node("castle_masonry:arrowslit_"..mwood.."_hole",{
drawtype = "nodebox",
description = (mwood.." Arrowslit with Hole"),
tiles = {tile},
groups = {choppy = 3, oddly_breakable_by_hand = 2, wood = 1},
sounds = default.node_sound_wood_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, -0.375, 0.5, -0.125, 0.375, 0.3125},{0.125, -0.375, 0.5, 0.5, 0.375, 0.3125},{-0.5, -0.5, 0.5, 0.5, -0.375, 0.3125},{0.0625, -0.125, 0.5, 0.125, 0.375, 0.3125},{-0.125, -0.125, 0.5, -0.0625, 0.375, 0.3125},{-0.5, 0.375, 0.5, 0.5, 0.5, 0.3125},{0.25, -0.5, 0.3125, 0.5, 0.5, 0.125},{-0.5, -0.5, 0.3125, -0.25, 0.5, 0.125},},},
})

minetest.register_node("castle_masonry:arrowslit_"..mwood.."_embrasure",{
drawtype = "nodebox",
description = (mwood.." Embrasure"),
tiles = {tile},
groups = {choppy = 3, oddly_breakable_by_hand = 2, wood = 1},
sounds = default.node_sound_wood_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.25, -0.5, 0.375, -0.125, 0.5, 0.5},{0.125, -0.5, 0.375, 0.25, 0.5, 0.5},{0.25, -0.5, 0.25, 0.5, 0.5, 0.5},{0.375, -0.5, 0.125, 0.5, 0.5, 0.25},{-0.5, -0.5, 0.25, -0.25, 0.5, 0.5},{-0.5, -0.5, 0.125, -0.375, 0.5, 0.25},},},
})

minetest.register_craft({output = "castle_masonry:arrowslit_"..mwood.." 6",recipe ={{wood,"",wood},{wood,"",wood},{wood,"",wood}},})
minetest.register_craft({output = "castle_masonry:arrowslit_"..mwood.."_cross",recipe = {{"castle_masonry:arrowslit_"..mwood} },})
minetest.register_craft({output = "castle_masonry:arrowslit_"..mwood.."_hole",recipe = {{"castle_masonry:arrowslit_"..mwood.."_cross"} },})
minetest.register_craft({output = "castle_masonry:arrowslit_"..mwood.."_embrasure",recipe = {{"castle_masonry:arrowslit_"..mwood.."_hole"} },})

--murder_holes
minetest.register_node("castle_masonry:hole_"..mwood,{
drawtype = "nodebox",
description = (mwood.." with Murder Hole"),
tiles = {tile},
groups = {choppy = 3, oddly_breakable_by_hand = 2, wood = 1},
sounds = default.node_sound_wood_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",fixed = {{-8/16,-8/16,-8/16,-4/16,8/16,8/16},{4/16,-8/16,-8/16,8/16,8/16,8/16},{-4/16,-8/16,-8/16,4/16,8/16,-4/16},{-4/16,-8/16,8/16,4/16,8/16,4/16},},},
})
	
minetest.register_node("castle_masonry:machicolation_"..mwood,{
drawtype = "nodebox",
description = (mwood.." with Machicolation"),
tiles = {tile},
groups = {choppy = 3, oddly_breakable_by_hand = 2, wood = 1},
sounds = default.node_sound_wood_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",fixed = {{-0.5, 0, -0.5, 0.5, 0.5, 0},{-0.5, -0.5, 0, -0.25, 0.5, 0.5},{0.25, -0.5, 0, 0.5, 0.5, 0.5},},},
})

minetest.register_craft({output = "castle_masonry:hole_"..mwood.." 4",recipe = {{"",wood, ""},{wood,"",wood},{"",wood, ""}},})
minetest.register_craft({output = "castle_masonry:machicolation_"..mwood,type="shapeless",recipe = {"castle_masonry:hole_"..mwood},})
minetest.register_craft({output = "castle_masonry:hole_"..mwood,type="shapeless",recipe = {"castle_masonry:machicolation_"..mwood},})

--pilars
minetest.register_node("castle_masonry:pillar_"..mwood.."_bottom",{
drawtype = "nodebox",
description = (mwood.." Pillar Base"),
tiles = {tile},
groups = {choppy = 3, oddly_breakable_by_hand = 2, wood = 1},
sounds = default.node_sound_wood_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5,-0.5,-0.5,0.5,-0.375,0.5},{-0.375,-0.375,-0.375,0.375,-0.125,0.375},{-0.25,-0.125,-0.25,0.25,0.5,0.25}, },},
})

minetest.register_node("castle_masonry:pillar_"..mwood.."_bottom_half",{
drawtype = "nodebox",
description = (mwood.." Half Pillar Base"),
tiles = {tile},
groups = {choppy = 3, oddly_breakable_by_hand = 2, wood = 1},
sounds = default.node_sound_wood_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, -0.5, 0, 0.5, -0.375, 0.5},{-0.375, -0.375, 0.125, 0.375, -0.125, 0.5},{-0.25, -0.125, 0.25, 0.25, 0.5, 0.5},},},
})

minetest.register_node("castle_masonry:pillar_"..mwood.."_top",{
drawtype = "nodebox",
description = (mwood.." Pillar Top"),
tiles = {tile},
groups = {choppy = 3, oddly_breakable_by_hand = 2, wood = 1},
sounds = default.node_sound_wood_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5,0.3125,-0.5,0.5,0.5,0.5}, {-0.375,0.0625,-0.375,0.375,0.3125,0.375}, {-0.25,-0.5,-0.25,0.25,0.0625,0.25},},},
})

minetest.register_node("castle_masonry:pillar_"..mwood.."_top_half",{
drawtype = "nodebox",
description = (mwood.." Half Pillar Top"),
tiles = {tile},
groups = {choppy = 3, oddly_breakable_by_hand = 2, wood = 1},
sounds = default.node_sound_wood_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, 0.3125, 0, 0.5, 0.5, 0.5},{-0.375, 0.0625, 0.125, 0.375, 0.3125, 0.5},{-0.25, -0.5, 0.25, 0.25, 0.0625, 0.5},},},
})	

minetest.register_node("castle_masonry:pillar_"..mwood.."_middle",{
drawtype = "nodebox",
description = (mwood.." Pillar Middle"),
tiles = {tile},
groups = {choppy = 3, oddly_breakable_by_hand = 2, wood = 1},
sounds = default.node_sound_wood_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.25,-0.5,-0.25,0.25,0.5,0.25},},},
})

minetest.register_node("castle_masonry:pillar_"..mwood.."_middle_half",{
drawtype = "nodebox",
description = (mwood.." Half Pillar Middle"),
tiles = {tile},
groups = {choppy = 3, oddly_breakable_by_hand = 2, wood = 1},
sounds = default.node_sound_wood_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.25, -0.5, 0.25, 0.25, 0.5, 0.5},},},
})

minetest.register_node("castle_masonry:pillar_"..mwood.."_crossbrace",{
drawtype = "nodebox",
description = (mwood.." Crossbrace"),
tiles = {tile},
groups = {choppy = 3, oddly_breakable_by_hand = 2, wood = 1},
sounds = default.node_sound_wood_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "connected",
fixed = {-0.25,0.25,-0.25,0.25,0.5,0.25},connect_front = {-0.25,0.25,-0.75,0.25,0.5,-0.25}, connect_left = {-0.25,0.25,-0.25,-0.75,0.5,0.25}, connect_back = {-0.25,0.25,0.25,0.25,0.5,0.75},connect_right = {0.25,0.25,-0.25,0.75,0.5,0.25},},
connects_to = {"castle_masonry:pillar_"..mwood.."_crossbrace","castle_masonry:pillar_"..mwood.."_extended_crossbrace","group:crossbrace_connectable"},
connect_sides = { "front", "left", "back", "right" },
})

minetest.register_node("castle_masonry:pillar_"..mwood.."_extended_crossbrace",{
drawtype = "nodebox",
description = (mwood.." Extended Crossbrace"),
tiles = {tile},
groups = {choppy = 3, oddly_breakable_by_hand = 2, wood = 1},
sounds = default.node_sound_wood_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {-1.25,0.25,-0.25,1.25,0.5,0.25},},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mwood.."_bottom 4",
recipe = {{"",wood,""},{"",wood,""},{wood,wood,wood}},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mwood.."_top 4",
recipe = {{wood,wood,wood},{"",wood,""},{"",wood,""}},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mwood.."_middle 2",
recipe = {{wood},{wood},{wood}},
})
	
minetest.register_craft({
output = "castle_masonry:pillar_"..mwood.."_crossbrace 10",
recipe = {{wood,"",wood},{"",wood,""},{wood,"",wood} },
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mwood.."_middle_half 2",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mwood.."_middle"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mwood.."_middle",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mwood.."_middle_half", "castle_masonry:pillar_"..mwood.."_middle_half"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mwood.."_top_half 2",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mwood.."_top"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mwood.."_top",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mwood.."_top_half", "castle_masonry:pillar_"..mwood.."_top_half"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mwood.."_bottom_half 2",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mwood.."_bottom"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mwood.."_bottom",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mwood.."_bottom_half", "castle_masonry:pillar_"..mwood.."_bottom_half"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mwood.."_extended_crossbrace",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mwood.."_crossbrace"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mwood.."_crossbrace",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mwood.."_extended_crossbrace"},
})

end
