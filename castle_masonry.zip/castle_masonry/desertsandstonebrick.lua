local desast = {{"desertsandstonebrick", "default:desert_sandstone_brick", "default_desert_sandstone_brick.png"},}
for i in ipairs(desast) do mdessan = desast[i][1] dessan = desast[i][2] tile = desast[i][3]

--arrowslit
minetest.register_node("castle_masonry:arrowslit_"..mdessan,{
drawtype = "nodebox",
description = (mdessan.."  Arrowslit"),
tiles = {tile},
groups = {cracky = 2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",fixed = {{-0.5, -0.375, 0.5, -0.0625, 0.375, 0.3125},{0.0625, -0.375, 0.5, 0.5, 0.375, 0.3125},{-0.5, 0.375, 0.5, 0.5, 0.5, 0.3125}, {-0.5, -0.5, 0.5, 0.5, -0.375, 0.3125},{0.25, -0.5, 0.3125, 0.5, 0.5, 0.125},{-0.5, -0.5, 0.3125, -0.25, 0.5, 0.125},},},
})

minetest.register_node("castle_masonry:arrowslit_"..mdessan.."_cross",{
drawtype = "nodebox",
description = (mdessan.." Arrowslit with Cross"),
tiles = {tile},
groups = {cracky = 2},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, -0.125, 0.5, -0.0625, 0.375, 0.3125},{0.0625, -0.125, 0.5, 0.5, 0.375, 0.3125},{-0.5, 0.375, 0.5, 0.5, 0.5, 0.3125},{-0.5, -0.5, 0.5, 0.5, -0.375, 0.3125},{0.0625, -0.375, 0.5, 0.5, -0.25, 0.3125},{-0.5, -0.375, 0.5, -0.0625, -0.25, 0.3125},{-0.5, -0.25, 0.5, -0.1875, -0.125, 0.3125},{0.1875, -0.25, 0.5, 0.5, -0.125, 0.3125},{0.25, -0.5, 0.3125, 0.5, 0.5, 0.125},{-0.5, -0.5, 0.3125, -0.25, 0.5, 0.125},},},
})

minetest.register_node("castle_masonry:arrowslit_"..mdessan.."_hole",{
drawtype = "nodebox",
description = (mdessan.." Arrowslit with Hole"),
groups = {cracky = 2},
sounds = default.node_sound_stone_defaults(),
tiles = {tile},
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, -0.375, 0.5, -0.125, 0.375, 0.3125},{0.125, -0.375, 0.5, 0.5, 0.375, 0.3125},{-0.5, -0.5, 0.5, 0.5, -0.375, 0.3125},{0.0625, -0.125, 0.5, 0.125, 0.375, 0.3125},{-0.125, -0.125, 0.5, -0.0625, 0.375, 0.3125},{-0.5, 0.375, 0.5, 0.5, 0.5, 0.3125},{0.25, -0.5, 0.3125, 0.5, 0.5, 0.125},{-0.5, -0.5, 0.3125, -0.25, 0.5, 0.125},},},
})

minetest.register_node("castle_masonry:arrowslit_"..mdessan.."_embrasure",{
drawtype = "nodebox",
description = (mdessan.." Embrasure"),
groups = {cracky = 2},
sounds = default.node_sound_stone_defaults(),
tiles = {tile},
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.25, -0.5, 0.375, -0.125, 0.5, 0.5},{0.125, -0.5, 0.375, 0.25, 0.5, 0.5},{0.25, -0.5, 0.25, 0.5, 0.5, 0.5},{0.375, -0.5, 0.125, 0.5, 0.5, 0.25},{-0.5, -0.5, 0.25, -0.25, 0.5, 0.5},{-0.5, -0.5, 0.125, -0.375, 0.5, 0.25},},},
})

minetest.register_craft({output = "castle_masonry:arrowslit_"..mdessan.." 6",recipe ={{dessan,"",dessan},{dessan,"",dessan},{dessan,"",dessan}},})
minetest.register_craft({output = "castle_masonry:arrowslit_"..mdessan.."_cross",recipe = {{"castle_masonry:arrowslit_"..mdessan} },})
minetest.register_craft({output = "castle_masonry:arrowslit_"..mdessan.."_hole",recipe = {{"castle_masonry:arrowslit_"..mdessan.."_cross"} },})
minetest.register_craft({output = "castle_masonry:arrowslit_"..mdessan.."_embrasure",recipe = {{"castle_masonry:arrowslit_"..mdessan.."_hole"} },})

--murder_holes
minetest.register_node("castle_masonry:hole_"..mdessan,{
drawtype = "nodebox",
description = (mdessan.." with Murder Hole"),
groups = {cracky = 2},
sounds = default.node_sound_stone_defaults(),
tiles = {tile},
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",fixed = {{-8/16,-8/16,-8/16,-4/16,8/16,8/16},{4/16,-8/16,-8/16,8/16,8/16,8/16},{-4/16,-8/16,-8/16,4/16,8/16,-4/16},{-4/16,-8/16,8/16,4/16,8/16,4/16},},},
})
	
minetest.register_node("castle_masonry:machicolation_"..mdessan,{
drawtype = "nodebox",
description = (mdessan.." with Machicolation"),
groups = {cracky = 2},
sounds = default.node_sound_stone_defaults(),
tiles = {tile},
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",fixed = {{-0.5, 0, -0.5, 0.5, 0.5, 0},{-0.5, -0.5, 0, -0.25, 0.5, 0.5},{0.25, -0.5, 0, 0.5, 0.5, 0.5},},},
})

minetest.register_craft({output = "castle_masonry:hole_"..mdessan.." 4",recipe = {{"",dessan, ""},{dessan,"",dessan},{"",dessan, ""}},})
minetest.register_craft({output = "castle_masonry:machicolation_"..mdessan,type="shapeless",recipe = {"castle_masonry:hole_"..mdessan},})
minetest.register_craft({output = "castle_masonry:hole_"..mdessan,type="shapeless",recipe = {"castle_masonry:machicolation_"..mdessan},})

--pilars
minetest.register_node("castle_masonry:pillar_"..mdessan.."_bottom",{
drawtype = "nodebox",
description = (mdessan.." Pillar Base"),
groups = {cracky = 2},
sounds = default.node_sound_stone_defaults(),
tiles = {tile},
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5,-0.5,-0.5,0.5,-0.375,0.5},{-0.375,-0.375,-0.375,0.375,-0.125,0.375},{-0.25,-0.125,-0.25,0.25,0.5,0.25}, },},
})

minetest.register_node("castle_masonry:pillar_"..mdessan.."_bottom_half",{
drawtype = "nodebox",
description = (mdessan.." Half Pillar Base"),
groups = {cracky = 2},
sounds = default.node_sound_stone_defaults(),
tiles = {tile},
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, -0.5, 0, 0.5, -0.375, 0.5},{-0.375, -0.375, 0.125, 0.375, -0.125, 0.5},{-0.25, -0.125, 0.25, 0.25, 0.5, 0.5},},},
})

minetest.register_node("castle_masonry:pillar_"..mdessan.."_top",{
drawtype = "nodebox",
description = (mdessan.." Pillar Top"),
groups = {cracky = 2},
sounds = default.node_sound_stone_defaults(),
tiles = {tile},
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5,0.3125,-0.5,0.5,0.5,0.5}, {-0.375,0.0625,-0.375,0.375,0.3125,0.375}, {-0.25,-0.5,-0.25,0.25,0.0625,0.25},},},
})

minetest.register_node("castle_masonry:pillar_"..mdessan.."_top_half",{
drawtype = "nodebox",
description = (mdessan.." Half Pillar Top"),
groups = {cracky = 2},
sounds = default.node_sound_stone_defaults(),
tiles = {tile},
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, 0.3125, 0, 0.5, 0.5, 0.5},{-0.375, 0.0625, 0.125, 0.375, 0.3125, 0.5},{-0.25, -0.5, 0.25, 0.25, 0.0625, 0.5},},},
})	

minetest.register_node("castle_masonry:pillar_"..mdessan.."_middle",{
drawtype = "nodebox",
description = (mdessan.." Pillar Middle"),
groups = {cracky = 2},
sounds = default.node_sound_stone_defaults(),
tiles = {tile},
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.25,-0.5,-0.25,0.25,0.5,0.25},},},
})

minetest.register_node("castle_masonry:pillar_"..mdessan.."_middle_half",{
drawtype = "nodebox",
description = (mdessan.." Half Pillar Middle"),
groups = {cracky = 2},
sounds = default.node_sound_stone_defaults(),
tiles = {tile},
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.25, -0.5, 0.25, 0.25, 0.5, 0.5},},},
})

minetest.register_node("castle_masonry:pillar_"..mdessan.."_crossbrace",{
drawtype = "nodebox",
description = (mdessan.." Crossbrace"),
groups = {cracky = 2},
sounds = default.node_sound_stone_defaults(),
tiles = {tile},
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "connected",
fixed = {-0.25,0.25,-0.25,0.25,0.5,0.25},connect_front = {-0.25,0.25,-0.75,0.25,0.5,-0.25}, connect_left = {-0.25,0.25,-0.25,-0.75,0.5,0.25}, connect_back = {-0.25,0.25,0.25,0.25,0.5,0.75},connect_right = {0.25,0.25,-0.25,0.75,0.5,0.25},},
connects_to = {"castle_masonry:pillar_"..mdessan.."_crossbrace","castle_masonry:pillar_"..mdessan.."_extended_crossbrace","group:crossbrace_connectable"},
connect_sides = { "front", "left", "back", "right"},
})

minetest.register_node("castle_masonry:pillar_"..mdessan.."_extended_crossbrace",{
drawtype = "nodebox",
description = (mdessan.." Extended Crossbrace"),
groups = {cracky = 2},
sounds = default.node_sound_stone_defaults(),
tiles = {tile},
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {-1.25,0.25,-0.25,1.25,0.5,0.25},},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mdessan.."_bottom 4",
recipe = {{"",dessan,""},{"",dessan,""},{dessan,dessan,dessan}},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mdessan.."_top 4",
recipe = {{dessan,dessan,dessan},{"",dessan,""},{"",dessan,""}},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mdessan.."_middle 2",
recipe = {{dessan},{dessan},{dessan}},
})
	
minetest.register_craft({
output = "castle_masonry:pillar_"..mdessan.."_crossbrace 10",
recipe = {{dessan,"",dessan},{"",dessan,""},{dessan,"",dessan} },
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mdessan.."_middle_half 2",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mdessan.."_middle"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mdessan.."_middle",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mdessan.."_middle_half", "castle_masonry:pillar_"..mdessan.."_middle_half"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mdessan.."_top_half 2",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mdessan.."_top"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mdessan.."_top",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mdessan.."_top_half", "castle_masonry:pillar_"..mdessan.."_top_half"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mdessan.."_bottom_half 2",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mdessan.."_bottom"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mdessan.."_bottom",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mdessan.."_bottom_half", "castle_masonry:pillar_"..mdessan.."_bottom_half"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mdessan.."_extended_crossbrace",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mdessan.."_crossbrace"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..mdessan.."_crossbrace",
type="shapeless",
recipe = {"castle_masonry:pillar_"..mdessan.."_extended_crossbrace"},
})

end
