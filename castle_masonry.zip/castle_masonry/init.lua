local log = minetest.log
local mp = minetest.get_modpath("castle_masonry")
local desertsandstone = false 
local stone =false --stone, cobble and brick
local desertstone = false --desert stone, desert stone brick
local sandstone = false 
local silversandstone = false
local obsidian = true --obsidian, obsidian block and obsidian brick
local castlewall = true --castlewall and dungeon stone
local wood = false --defaul woods
local ice = false --ice and snow

if stone == true then log("info","[Castle_Masonry] Enabling Stone, Stonebrick and Cobble")
dofile(mp.."/stone.lua")
dofile(mp.."/cobble.lua")
dofile(mp.."/stonebrick.lua") end

if desertsandstone == true then log("info","[Castle_Masonry] Enabling Desertsand Stone and Brick") 
dofile(mp.."/desertsandstone.lua")
dofile(mp.."/desertsandstonebrick.lua") end 

if desertstone == true then log("info","[Castle_Masonry] Enabling Desertstone and brick") 
dofile(mp.."/desertstone.lua") 
dofile(mp.."/desertstonebrick.lua") end

if sandstone == true then log("info","[Castle_Masonry] Enabling Sandstone and brick") 
dofile(mp.."/sandstone.lua") 
dofile(mp.."/sandstonebrick.lua") end

if silversandstone == true then log("info","[Castle_Masonry] Enabling Silversandstone and brick") 
dofile(mp.."/silversandstone.lua")
dofile(mp.."/silversandstonebrick.lua") end
 
if obsidian == true then log("info","[Castle_Masonry] Enabling Obsidian and brick") 
dofile(mp.."/obsidian.lua") 
dofile(mp.."/obsidianblock.lua")
dofile(mp.."/obsidianbrick.lua") end

if castlewall == true then log("info","[Castle_Masonry] Enabling Castlewall and Dungeon Stone") 
--dofile(mp.."/castlewall.lua")
dofile(mp.."/dungeon_stone.lua") end

if wood == true then log("info","[Castle_Masonry] Enabling all kind of default woods") 
dofile(mp.."/wood.lua")
dofile(mp.."/woodaspen.lua")
dofile(mp.."/woodacacia.lua")
dofile(mp.."/woodjungle.lua")
dofile(mp.."/woodpine.lua") end
 
if ice == true then log("info","[Castle_Masonry] Enabling Ice and Snow") 
dofile(mp.."/ice.lua")
dofile(mp.."/snow.lua") end
