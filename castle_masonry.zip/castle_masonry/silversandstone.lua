local silsands = {{"silversandstone", "default:silver_sandstone", "default_silver_sandstone.png"},}
for i in ipairs(silsands) do msilsansto = silsands[i][1] silsansto = silsands[i][2] tile = silsands[i][3]
--arrowslit
minetest.register_node("castle_masonry:arrowslit_"..msilsansto,{
drawtype = "nodebox",
description = (msilsansto.." Arrowslit"),
tiles = {tile},
groups = {crumbly = 1, cracky = 3},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",fixed = {{-0.5, -0.375, 0.5, -0.0625, 0.375, 0.3125},{0.0625, -0.375, 0.5, 0.5, 0.375, 0.3125},{-0.5, 0.375, 0.5, 0.5, 0.5, 0.3125}, {-0.5, -0.5, 0.5, 0.5, -0.375, 0.3125},{0.25, -0.5, 0.3125, 0.5, 0.5, 0.125},{-0.5, -0.5, 0.3125, -0.25, 0.5, 0.125},},},
})

minetest.register_node("castle_masonry:arrowslit_"..msilsansto.."_cross",{
drawtype = "nodebox",
description = (msilsansto.." Arrowslit with Cross"),
tiles = {tile},
groups = {crumbly = 1, cracky = 3},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, -0.125, 0.5, -0.0625, 0.375, 0.3125},{0.0625, -0.125, 0.5, 0.5, 0.375, 0.3125},{-0.5, 0.375, 0.5, 0.5, 0.5, 0.3125},{-0.5, -0.5, 0.5, 0.5, -0.375, 0.3125},{0.0625, -0.375, 0.5, 0.5, -0.25, 0.3125},{-0.5, -0.375, 0.5, -0.0625, -0.25, 0.3125},{-0.5, -0.25, 0.5, -0.1875, -0.125, 0.3125},{0.1875, -0.25, 0.5, 0.5, -0.125, 0.3125},{0.25, -0.5, 0.3125, 0.5, 0.5, 0.125},{-0.5, -0.5, 0.3125, -0.25, 0.5, 0.125},},},
})

minetest.register_node("castle_masonry:arrowslit_"..msilsansto.."_hole",{
drawtype = "nodebox",
description = (msilsansto.." Arrowslit with Hole"),
tiles = {tile},
groups = {crumbly = 1, cracky = 3},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, -0.375, 0.5, -0.125, 0.375, 0.3125},{0.125, -0.375, 0.5, 0.5, 0.375, 0.3125},{-0.5, -0.5, 0.5, 0.5, -0.375, 0.3125},{0.0625, -0.125, 0.5, 0.125, 0.375, 0.3125},{-0.125, -0.125, 0.5, -0.0625, 0.375, 0.3125},{-0.5, 0.375, 0.5, 0.5, 0.5, 0.3125},{0.25, -0.5, 0.3125, 0.5, 0.5, 0.125},{-0.5, -0.5, 0.3125, -0.25, 0.5, 0.125},},},
})

minetest.register_node("castle_masonry:arrowslit_"..msilsansto.."_embrasure",{
drawtype = "nodebox",
description = (msilsansto.." Embrasure"),
tiles = {tile},
groups = {crumbly = 1, cracky = 3},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.25, -0.5, 0.375, -0.125, 0.5, 0.5},{0.125, -0.5, 0.375, 0.25, 0.5, 0.5},{0.25, -0.5, 0.25, 0.5, 0.5, 0.5},{0.375, -0.5, 0.125, 0.5, 0.5, 0.25},{-0.5, -0.5, 0.25, -0.25, 0.5, 0.5},{-0.5, -0.5, 0.125, -0.375, 0.5, 0.25},},},
})

minetest.register_craft({output = "castle_masonry:arrowslit_"..msilsansto.." 6",recipe ={{silsansto,"",silsansto},{silsansto,"",silsansto},{silsansto,"",silsansto}},})
minetest.register_craft({output = "castle_masonry:arrowslit_"..msilsansto.."_cross",recipe = {{"castle_masonry:arrowslit_"..msilsansto} },})
minetest.register_craft({output = "castle_masonry:arrowslit_"..msilsansto.."_hole",recipe = {{"castle_masonry:arrowslit_"..msilsansto.."_cross"} },})
minetest.register_craft({output = "castle_masonry:arrowslit_"..msilsansto.."_embrasure",recipe = {{"castle_masonry:arrowslit_"..msilsansto.."_hole"} },})

--murder_holes
minetest.register_node("castle_masonry:hole_"..msilsansto,{
drawtype = "nodebox",
description = (msilsansto.." with Murder Hole"),
tiles = {tile},
groups = {crumbly = 1, cracky = 3},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",fixed = {{-8/16,-8/16,-8/16,-4/16,8/16,8/16},{4/16,-8/16,-8/16,8/16,8/16,8/16},{-4/16,-8/16,-8/16,4/16,8/16,-4/16},{-4/16,-8/16,8/16,4/16,8/16,4/16},},},
})
	
minetest.register_node("castle_masonry:machicolation_"..msilsansto,{
drawtype = "nodebox",
description = (msilsansto.." with Machicolation"),
tiles = {tile},
groups = {crumbly = 1, cracky = 3},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",fixed = {{-0.5, 0, -0.5, 0.5, 0.5, 0},{-0.5, -0.5, 0, -0.25, 0.5, 0.5},{0.25, -0.5, 0, 0.5, 0.5, 0.5},},},
})

minetest.register_craft({output = "castle_masonry:hole_"..msilsansto.." 4",recipe = {{"",silsansto, ""},{silsansto,"",silsansto},{"",silsansto, ""}},})
minetest.register_craft({output = "castle_masonry:machicolation_"..msilsansto,type="shapeless",recipe = {"castle_masonry:hole_"..msilsansto},})
minetest.register_craft({output = "castle_masonry:hole_"..msilsansto,type="shapeless",recipe = {"castle_masonry:machicolation_"..msilsansto},})

--pilars
minetest.register_node("castle_masonry:pillar_"..msilsansto.."_bottom",{
drawtype = "nodebox",
description = (msilsansto.." Pillar Base"),
tiles = {tile},
groups = {crumbly = 1, cracky = 3},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5,-0.5,-0.5,0.5,-0.375,0.5},{-0.375,-0.375,-0.375,0.375,-0.125,0.375},{-0.25,-0.125,-0.25,0.25,0.5,0.25}, },},
})

minetest.register_node("castle_masonry:pillar_"..msilsansto.."_bottom_half",{
drawtype = "nodebox",
description = (msilsansto.." Half Pillar Base"),
tiles = {tile},
groups = {crumbly = 1, cracky = 3},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, -0.5, 0, 0.5, -0.375, 0.5},{-0.375, -0.375, 0.125, 0.375, -0.125, 0.5},{-0.25, -0.125, 0.25, 0.25, 0.5, 0.5},},},
})

minetest.register_node("castle_masonry:pillar_"..msilsansto.."_top",{
drawtype = "nodebox",
description = (msilsansto.." Pillar Top"),
tiles = {tile},
groups = {crumbly = 1, cracky = 3},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5,0.3125,-0.5,0.5,0.5,0.5}, {-0.375,0.0625,-0.375,0.375,0.3125,0.375}, {-0.25,-0.5,-0.25,0.25,0.0625,0.25},},},
})

minetest.register_node("castle_masonry:pillar_"..msilsansto.."_top_half",{
drawtype = "nodebox",
description = (msilsansto.." Half Pillar Top"),
tiles = {tile},
groups = {crumbly = 1, cracky = 3},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.5, 0.3125, 0, 0.5, 0.5, 0.5},{-0.375, 0.0625, 0.125, 0.375, 0.3125, 0.5},{-0.25, -0.5, 0.25, 0.25, 0.0625, 0.5},},},
})	

minetest.register_node("castle_masonry:pillar_"..msilsansto.."_middle",{
drawtype = "nodebox",
description = (msilsansto.." Pillar Middle"),
tiles = {tile},
groups = {crumbly = 1, cracky = 3},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.25,-0.5,-0.25,0.25,0.5,0.25},},},
})

minetest.register_node("castle_masonry:pillar_"..msilsansto.."_middle_half",{
drawtype = "nodebox",
description = (msilsansto.." Half Pillar Middle"),
tiles = {tile},
groups = {crumbly = 1, cracky = 3},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {{-0.25, -0.5, 0.25, 0.25, 0.5, 0.5},},},
})

minetest.register_node("castle_masonry:pillar_"..msilsansto.."_crossbrace",{
drawtype = "nodebox",
description = (msilsansto.." Crossbrace"),
tiles = {tile},
groups = {crumbly = 1, cracky = 3},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "connected",
fixed = {-0.25,0.25,-0.25,0.25,0.5,0.25},connect_front = {-0.25,0.25,-0.75,0.25,0.5,-0.25}, connect_left = {-0.25,0.25,-0.25,-0.75,0.5,0.25}, connect_back = {-0.25,0.25,0.25,0.25,0.5,0.75},connect_right = {0.25,0.25,-0.25,0.75,0.5,0.25},},
connects_to = {"castle_masonry:pillar_"..msilsansto.."_crossbrace","castle_masonry:pillar_"..msilsansto.."_extended_crossbrace","group:crossbrace_connectable"},
connect_sides = { "front", "left", "back", "right" },
})

minetest.register_node("castle_masonry:pillar_"..msilsansto.."_extended_crossbrace",{
drawtype = "nodebox",
description = (msilsansto.." Extended Crossbrace"),
tiles = {tile},
groups = {crumbly = 1, cracky = 3},
sounds = default.node_sound_stone_defaults(),
paramtype = "light",
paramtype2 = "facedir",
node_box = {type = "fixed",
fixed = {-1.25,0.25,-0.25,1.25,0.5,0.25},},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..msilsansto.."_bottom 4",
recipe = {{"",silsansto,""},{"",silsansto,""},{silsansto,silsansto,silsansto}},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..msilsansto.."_top 4",
recipe = {{silsansto,silsansto,silsansto},{"",silsansto,""},{"",silsansto,""}},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..msilsansto.."_middle 2",
recipe = {{silsansto},{silsansto},{silsansto}},
})
	
minetest.register_craft({
output = "castle_masonry:pillar_"..msilsansto.."_crossbrace 10",
recipe = {{silsansto,"",silsansto},{"",silsansto,""},{silsansto,"",silsansto} },
})

minetest.register_craft({
output = "castle_masonry:pillar_"..msilsansto.."_middle_half 2",
type="shapeless",
recipe = {"castle_masonry:pillar_"..msilsansto.."_middle"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..msilsansto.."_middle",
type="shapeless",
recipe = {"castle_masonry:pillar_"..msilsansto.."_middle_half", "castle_masonry:pillar_"..msilsansto.."_middle_half"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..msilsansto.."_top_half 2",
type="shapeless",
recipe = {"castle_masonry:pillar_"..msilsansto.."_top"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..msilsansto.."_top",
type="shapeless",
recipe = {"castle_masonry:pillar_"..msilsansto.."_top_half", "castle_masonry:pillar_"..msilsansto.."_top_half"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..msilsansto.."_bottom_half 2",
type="shapeless",
recipe = {"castle_masonry:pillar_"..msilsansto.."_bottom"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..msilsansto.."_bottom",
type="shapeless",
recipe = {"castle_masonry:pillar_"..msilsansto.."_bottom_half", "castle_masonry:pillar_"..msilsansto.."_bottom_half"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..msilsansto.."_extended_crossbrace",
type="shapeless",
recipe = {"castle_masonry:pillar_"..msilsansto.."_crossbrace"},
})

minetest.register_craft({
output = "castle_masonry:pillar_"..msilsansto.."_crossbrace",
type="shapeless",
recipe = {"castle_masonry:pillar_"..msilsansto.."_extended_crossbrace"},
})

end
