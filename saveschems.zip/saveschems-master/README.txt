saveschems 0.2.2 by paramat and sofar
For Minetest 0.4.13 and later
Depends default flowers
Licenses: Code MIT. Schematics CC BY-SA 3.0

This mod exists to help create (mostly tree) decorations for the
in-game mapgen code. The code in this mod is used to create the
official minetest_game tree decorations from a Lua table format,
and the output is minetest's MTS format (a binary format).

This mod has no gameplay value, and is only useful for developers.
