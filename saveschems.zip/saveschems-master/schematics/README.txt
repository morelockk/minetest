The schematic files (.mts format) will be written to this folder if
you load and enable this module.
