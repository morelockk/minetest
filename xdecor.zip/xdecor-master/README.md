## X-Decor ##

##### A decoration mod meant to be simple and well-featured. #####
##### It adds a bunch of cute cubes, various mechanisms and stuff for [cutting](https://forum.minetest.net/viewtopic.php?f=11&t=14085), [enchanting](https://forum.minetest.net/viewtopic.php?f=11&t=14087), cooking, etc. #####
##### This mod is a lightweight alternative to Home Decor and More Blocks all together. #####

### Credits ###

##### Special thanks to Gambit for the textures from the PixelBOX pack for Minetest. #####

##### Thanks to all contributors that keep this mod alive. #####

![Preview](http://i.imgur.com/AVoyCQy.png)
